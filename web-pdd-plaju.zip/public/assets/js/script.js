document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");
    const forgotForm = document.getElementById("forgot-form");

    const showRegisterLink = document.getElementById("show-register");
    const showLoginLinkFromRegister = document.getElementById("show-login");
    const showForgotLink = document.getElementById("show-forgot");
    const showLoginLinkFromForgot = document.getElementById(
        "show-login-from-forgot"
    );

    function showForm(formToShow) {
        [loginForm, registerForm, forgotForm].forEach((form) => {
            if (form) {
                if (form === formToShow) {
                    form.classList.add("active");
                } else {
                    form.classList.remove("active");
                }
            }
        });
    }

    if (showRegisterLink) {
        showRegisterLink.addEventListener("click", function (e) {
            e.preventDefault();
            showForm(registerForm);
        });
    }

    if (showLoginLinkFromRegister) {
        showLoginLinkFromRegister.addEventListener("click", function (e) {
            e.preventDefault();
            showForm(loginForm);
        });
    }

    if (showForgotLink) {
        showForgotLink.addEventListener("click", function (e) {
            e.preventDefault();
            showForm(forgotForm);
        });
    }

    if (showLoginLinkFromForgot) {
        showLoginLinkFromForgot.addEventListener("click", function (e) {
            e.preventDefault();
            showForm(loginForm);
        });
    }

    if (loginForm) {
        showForm(loginForm);
    } else if (registerForm) {
        showForm(registerForm);
    } else if (forgotForm) {
        showForm(forgotForm);
    }
});
