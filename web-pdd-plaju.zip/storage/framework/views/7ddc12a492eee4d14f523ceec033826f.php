

<?php $__env->startSection('title', 'Laporan Pengiriman'); ?>

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Laporan Pengiriman</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('gudang.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Laporan Pengiriman</a></li>
        </ul>
    </div>
    
    <a href="<?php echo e(route('gudang.reports')); ?>?download=true&start_date=<?php echo e($startDate); ?>&end_date=<?php echo e($endDate); ?>" class="btn-download">
        <i class='bx bxs-file-pdf'></i>
        <span class="text">Download PDF</span>
    </a>
</div>

<?php if(session('error')): ?>
<div class="alert alert-error">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Filter Laporan</h3>
        </div>
        
        <form action="<?php echo e(route('gudang.reports')); ?>" method="GET" class="filter-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="start_date">Tanggal Mulai</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo e($startDate); ?>">
                </div>
                
                <div class="form-group">
                    <label for="end_date">Tanggal Akhir</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo e($endDate); ?>">
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn-filter">Filter</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Laporan Pengiriman: <?php echo e(date('d/m/Y', strtotime($startDate))); ?> - <?php echo e(date('d/m/Y', strtotime($endDate))); ?></h3>
            <div class="summary-info">
                <span>Total: <?php echo e($deliveries->count()); ?></span> |
                <span class="status pending">Pending: <?php echo e($deliveries->where('status', 'pending')->count()); ?></span> | 
                <span class="status process">Proses: <?php echo e($deliveries->where('status', 'process')->count()); ?></span> |
                <span class="status completed">Selesai: <?php echo e($deliveries->where('status', 'completed')->count()); ?></span>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Pemesan</th>
                    <th>Type Mobil</th>
                    <th>Tanggal Delivery</th>
                    <th>Sales</th>
                    <th>Status</th>
                    <th>Pengiriman Aktual</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($delivery->no_spk); ?></td>
                    <td><?php echo e($delivery->nama_pemesan); ?></td>
                    <td><?php echo e($delivery->type_mobil); ?></td>
                    <td><?php echo e($delivery->tanggal_delivery->format('d/m/Y')); ?> <?php echo e($delivery->jam_delivery); ?></td>
                    <td><?php echo e($delivery->user->username); ?></td>
                    <td>
                        <?php if($delivery->status == 'completed'): ?>
                            <span class="status <?php echo e($delivery->is_rescheduled ? 'terlambat' : 'completed'); ?>">Selesai</span>
                        <?php else: ?>
                            <span class="status <?php echo e($delivery->status); ?>"><?php echo e(ucfirst($delivery->status)); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($delivery->actual_delivery_date): ?>
                            <?php echo e($delivery->actual_delivery_date->format('d/m/Y')); ?>

                            <?php if($delivery->actual_delivery_time): ?>
                                <?php echo e($delivery->actual_delivery_time); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">Tidak ada data pengiriman dalam periode ini</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .filter-form {
        margin-bottom: 20px;
    }
    .form-row {
        display: flex;
        gap: 15px;
        align-items: flex-end;
    }
    .form-group {
        flex: 1;
    }
    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
    }
    .form-group input {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
    .btn-filter {
        background-color: #3c91e6;
        color: white;
        border: none;
        padding: 9px 20px;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn-filter:hover {
        background-color: #2980b9;
    }
    .status {
        padding: 2px 10px;
        border-radius: 20px;
        font-size: 12px;
    }
    .status.pending {
        background-color: #ff6b6b;
        color: white;
    }
    .status.process {
        background-color: #ffce26;
        color: black;
    }
    .status.completed {
        background-color: #4cd137;
        color: white;
    }
    .text-center {
        text-align: center;
    }
    .summary-info {
        font-size: 13px;
    }
    .summary-info .status {
        padding: 2px 5px;
        font-size: 11px;
    }
    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 5px;
    }
    .alert-error {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/gudang/reports.blade.php ENDPATH**/ ?>