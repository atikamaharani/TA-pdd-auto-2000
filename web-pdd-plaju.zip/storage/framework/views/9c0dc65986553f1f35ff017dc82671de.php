

<?php $__env->startSection('title', 'Tambah Karyawan'); ?>

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Tambah Karyawan Baru</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="<?php echo e(route('admin.users.index')); ?>">Data Karyawan</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Tambah</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Form Tambah Karyawan</h3>
        </div>
        <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select id="role" name="role" required>
                    <option value="">Pilih Role</option>
                    <option value="admin" <?php echo e(old('role') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                    <option value="sales" <?php echo e(old('role') == 'sales' ? 'selected' : ''); ?>>Sales</option>
                    <option value="gudang" <?php echo e(old('role') == 'gudang' ? 'selected' : ''); ?>>Gudang</option>
                </select>
            </div>
            <div class="form-group form-buttons">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn-cancel">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .form-horizontal .form-group { margin-bottom: 15px; }
    .form-horizontal label { display: block; margin-bottom: 5px; font-weight: 500; }
    .form-horizontal input, .form-horizontal select { width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
    .form-buttons { margin-top: 20px; display: flex; gap: 10px; }
    .btn-submit, .btn-cancel { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; color: white; text-decoration: none; }
    .btn-submit { background-color: var(--red); }
    .btn-cancel { background-color: #6c757d; }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/admin/users/create.blade.php ENDPATH**/ ?>