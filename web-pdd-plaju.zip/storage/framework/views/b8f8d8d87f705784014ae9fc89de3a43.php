

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Input Delivery Request</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('sales.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Input Delivery Request</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Form Input Delivery Request</h3>
        </div>
        
        <form action="<?php echo e(route('sales.store_delivery')); ?>" method="POST" class="delivery-form">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group">
                    <label for="salesforce">Salesforce / SPV</label>
                    <input type="text" id="salesforce" name="salesforce" required value="<?php echo e(old('salesforce')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="nama_pemesan">Nama Pemesan</label>
                    <input type="text" id="nama_pemesan" name="nama_pemesan" required value="<?php echo e(old('nama_pemesan')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="no_hp">No HP</label>
                    <input type="text" id="no_hp" name="no_hp" required value="<?php echo e(old('no_hp')); ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="no_spk">No SPK</label>
                    <input type="text" id="no_spk" name="no_spk" required value="<?php echo e(old('no_spk')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="type_mobil">Type Mobil</label>
                    <input type="text" id="type_mobil" name="type_mobil" required value="<?php echo e(old('type_mobil')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="warna">Warna</label>
                    <input type="text" id="warna" name="warna" required value="<?php echo e(old('warna')); ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="posisi_unit">Posisi Unit</label>
                    <input type="text" id="posisi_unit" name="posisi_unit" required value="<?php echo e(old('posisi_unit')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="no_rangka">No Rangka</label>
                    <input type="text" id="no_rangka" name="no_rangka" required value="<?php echo e(old('no_rangka')); ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="cara_bayar">Cara Bayar</label>
                    <select id="cara_bayar" name="cara_bayar" required>
                        <option value="">Pilih Metode</option>
                        <option value="Tunai" <?php echo e(old('cara_bayar') == 'Tunai' ? 'selected' : ''); ?>>Tunai</option>
                        <option value="Kredit" <?php echo e(old('cara_bayar') == 'Kredit' ? 'selected' : ''); ?>>Kredit</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="leasing">Leasing</label>
                    <input type="text" id="leasing" name="leasing" value="<?php echo e(old('leasing')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="status_transaksi">Status Transaksi</label>
                    <input type="text" id="status_transaksi" name="status_transaksi" required value="<?php echo e(old('status_transaksi', 'DO')); ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="tanggal_delivery">Tanggal Delivery</label>
                    <input type="date" id="tanggal_delivery" name="tanggal_delivery" required value="<?php echo e(old('tanggal_delivery')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="jam_delivery">Jam Delivery</label>
                    <input type="time" id="jam_delivery" name="jam_delivery" required value="<?php echo e(old('jam_delivery')); ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="lokasi_delivery">Lokasi Delivery</label>
                    <input type="text" id="lokasi_delivery" name="lokasi_delivery" required value="<?php echo e(old('lokasi_delivery')); ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="catatan">Catatan</label>
                    <textarea id="catatan" name="catatan" rows="3"><?php echo e(old('catatan')); ?></textarea>
                </div>
            </div>
            
            <div class="form-row">
                <button type="submit" class="btn-submit">Submit Request</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .delivery-form {
        width: 100%;
    }
    .form-row {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 15px;
        gap: 15px;
    }
    .form-group {
        flex: 1;
        min-width: 250px;
    }
    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
    }
    .form-group input, .form-group select, .form-group textarea {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
    }
    .btn-submit {
        background-color: #d71920;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s;
        font-size: 14px;
    }
    .btn-submit:hover {
        background-color: #b5141a;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Artditya\Downloads\web-pdd-plaju (1)\web-pdd-plaju\resources\views/sales/input_delivery.blade.php ENDPATH**/ ?>