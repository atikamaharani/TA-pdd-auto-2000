

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Data Pengiriman</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Data Pengiriman</a></li>
        </ul>
    </div>
</div>

<ul class="box-info">
    <li>
        <i class='bx bxs-calendar'></i>
        <span class="text">
            <h3><?php echo e($stats['total']); ?></h3>
            <p>Total Pengiriman</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-time-five'></i>
        <span class="text">
            <h3><?php echo e($stats['pending']); ?></h3>
            <p>Pending</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-truck'></i>
        <span class="text">
            <h3><?php echo e($stats['process']); ?></h3>
            <p>Dalam Proses</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-check-circle'></i>
        <span class="text">
            <h3><?php echo e($stats['completed']); ?></h3>
            <p>Selesai</p>
        </span>
    </li>
</ul>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Daftar Seluruh Pengiriman</h3>
            <div class="search-container">
                <form action="<?php echo e(route('admin.delivery_data')); ?>" method="GET">
                    <input type="text" name="search" placeholder="Cari (No SPK, Pemesan, Mobil...)" value="<?php echo e(request('search')); ?>">
                    <button type="submit"><i class='bx bx-search'></i></button>
                </form>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Nama Pemesan</th>
                    <th>Type Mobil</th>
                    <th>Sales</th>
                    <th>Jadwal Delivery</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deliveryRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($delivery->no_spk); ?></td>
                    <td><?php echo e($delivery->nama_pemesan); ?></td>
                    <td><?php echo e($delivery->type_mobil); ?></td>
                    <td><?php echo e($delivery->user->username); ?></td>
                    <td><?php echo e($delivery->tanggal_delivery->format('d/m/Y')); ?></td>
                    <td>
                        <?php if($delivery->status == 'completed'): ?>
                            <span class="status <?php echo e($delivery->is_rescheduled ? 'terlambat' : 'completed'); ?>">Selesai</span>
                        <?php else: ?>
                            <span class="status <?php echo e($delivery->status); ?>"><?php echo e(ucfirst($delivery->status)); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.show_delivery', $delivery->id)); ?>" class="btn-view">Detail</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" style="text-align: center;">Tidak ada data pengiriman.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
     <div class="pagination">
        <?php echo e($deliveryRequests->appends(request()->query())->links()); ?>

    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .btn-view { background-color: #3c91e6; color: white; padding: 5px 10px; border-radius: 5px; text-decoration: none; }
    .search-container { display: flex; margin-left: auto; }
    .search-container form { display: flex; }
    .search-container input { width: 200px; padding: 8px 10px; border: 1px solid #ddd; border-radius: 20px 0 0 20px; outline: none; }
    .search-container button { padding: 0 10px; border: none; background: var(--red); color: white; border-radius: 0 20px 20px 0; cursor: pointer; }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Artditya\Downloads\web-pdd-plaju (1)\web-pdd-plaju\resources\views/admin/delivery_data.blade.php ENDPATH**/ ?>