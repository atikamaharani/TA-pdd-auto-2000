<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>PDD Auto</title>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
  <div class="auth-wrapper">
    <div class="image-container">
      <img src="<?php echo e(asset('assets/img/logo-auto2000.png')); ?>" alt="Car Sale Illustration">
    </div>

    <div id="auth-container">
      <div class="container">

        <?php if(session('success')): ?>
        <div class="auth-alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="error-message">
          <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <div class="error-message">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>

        <form id="login-form" class="active" method="POST" action="<?php echo e(url('/login')); ?>">
          <?php echo csrf_field(); ?>
          <div class="title">Login</div>
          <div class="form-group">
            <label for="login-username">Username</label>
            <div class="input-group">
              <input type="text" id="login-username" name="username" placeholder="Username" required value="<?php echo e(old('username')); ?>" />
              <i class='bx bx-envelope'></i>
            </div>
          </div>
          <div class="form-group">
            <label for="login-password">Password</label>
            <div class="input-group">
              <input type="password" id="login-password" name="password" placeholder="Password" required />
              <i class='bx bx-lock-alt'></i>
            </div>
          </div>
          <button class="btn-submit" type="submit">Login</button>
          <!-- <div class="forgot-text"><a href="#" id="show-forgot">Lupa Password?</a></div> -->
        </form>

        
      </div>
    </div>
  </div>

  <script>
  setTimeout(() => {
    document.querySelectorAll('.auth-alert-success, .error-message').forEach(el => {
      el.classList.add('fade-out'); 
      el.classList.add('hidden');
      setTimeout(() => el.remove(), 400);
    });
  }, 2000);
</script>
  <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Artditya\Downloads\web-pdd-plaju (1)\web-pdd-plaju\resources\views/auth/login.blade.php ENDPATH**/ ?>