

<?php $__env->startSection('content'); ?>
<div class="head-title">
  <div class="left">
    <h1>Selamat Datang di Dashboard Gudang</h1>
     <ul class="breadcrumb">
      <li><a href="<?php echo e(route('gudang.dashboard')); ?>">Dashboard</a></li>
      <li><i class='bx bx-chevron-right'></i></li>
      <li><a class="active" href="#">Home</a></li>
    </ul>
  </div>
  <a href="<?php echo e(route('gudang.delivery_requests')); ?>" class="btn-download">
    <i class='bx bxs-car'></i>
     <span class="text">Lihat Semua Request</span>
  </a>
</div>

<ul class="box-info">
  <li>
    <i class='bx bxs-file-doc'></i>
    <span class="text">
      <h3><?php echo e($statistics['request']); ?></h3>
      <p>Total Request</p>
    </span>
  </li>
  <li>
    <i class='bx bxs-truck'></i>
    <span class="text">
      <h3><?php echo e($statistics['process']); ?></h3>
      <p>Sedang Diproses</p>
    </span>
  </li>
  <li>
    <i class='bx bxs-check-circle'></i>
    <span class="text">
      <h3><?php echo e($statistics['completed']); ?></h3>
      <p>Terkirim</p>
    </span>
  </li>
</ul>

<div class="table-data">
  <div class="order">
    <div class="head">
       <h3>Permintaan Pengiriman Terbaru</h3>
      <i class='bx bx-search'></i>
      <i class='bx bx-filter'></i>
    </div>
    <table>
      <thead>
        <tr>
          <th>No SPK</th>
          <th>Pemesan</th>
          <th>Type Mobil</th>
          <th>Sales</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
         <?php $__empty_1 = true; $__currentLoopData = $latestRequestsForGudang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($delivery->no_spk); ?></td>
          <td><?php echo e($delivery->nama_pemesan); ?></td>
          <td><?php echo e($delivery->type_mobil); ?></td>
          <td><?php echo e($delivery->user->username ?? 'N/A'); ?></td>
          <td>
            <?php if($delivery->status == 'completed'): ?>
              <span class="status <?php echo e($delivery->is_rescheduled ? 'terlambat' : 'completed'); ?>">Selesai</span>
            <?php else: ?>
              <span class="status <?php echo e($delivery->status); ?>"><?php echo e(ucfirst($delivery->status)); ?></span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="5" style="text-align: center;">Tidak ada permintaan pengiriman.</td>
        </tr>
         <?php endif; ?>
      </tbody>
    </table>
     <?php if($totalRequestsForGudang > 3): ?>
      <a href="<?php echo e(route('gudang.delivery_requests')); ?>" class="view-all-link">Lihat Semua Permintaan &rarr;</a>
    <?php endif; ?>
  </div>
  
   <div class="todo">
     <div class="head">
      <h3>Notifikasi Terbaru</h3>
    </div>
    <ul class="todo-list">
      <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li class="<?php echo e(strpos(strtolower($notification->content), 'pending') !== false ? 'not-completed' : (strpos(strtolower($notification->content), 'proses') !== false || strpos(strtolower($notification->content), 'process') !== false ? 'process' : (strpos(strtolower($notification->content), 'selesai') !== false || strpos(strtolower($notification->content), 'completed') !== false ? 'completed' : ($notification->is_read ? 'completed' : 'not-completed')))); ?>">
        <p><?php echo e(Str::limit($notification->content, 50)); ?></p>
        <i class='bx bx-check <?php echo e($notification->is_read ? "" : "bx-circle"); ?>'></i>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
       <li class="not-completed">
        <p>Belum ada notifikasi baru</p>
      </li>
      <?php endif; ?>
    </ul>
     <?php if($totalNotifications > 3): ?>
      <a href="<?php echo e(route('notifications.index')); ?>" class="view-all-link">Lihat Semua Notifikasi &rarr;</a>
     <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/dashboard/gudang.blade.php ENDPATH**/ ?>