

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Detail Delivery Request</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('gudang.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="<?php echo e(route('gudang.delivery_requests')); ?>">Delivery Requests</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Detail</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order detail-card">
        <div class="head">
            <h3>Informasi Pengiriman #<?php echo e($deliveryRequest->id); ?></h3>
            <div class="status-badge <?php echo e($deliveryRequest->status); ?>">
                <?php if($deliveryRequest->status == 'pending'): ?>
                    Pending
                <?php elseif($deliveryRequest->status == 'process'): ?>
                    Proses
                <?php elseif($deliveryRequest->status == 'completed'): ?>
                    Selesai
                <?php elseif($deliveryRequest->status == 'terlambat'): ?>
                    Terlambat
                <?php endif; ?>
            </div>
        </div>
        
        <div class="info-section">
            <div class="info-column">
                <div class="info-group">
                    <h4>Informasi Customer</h4>
                    <div class="info-row">
                        <span class="label">Nama Pemesan:</span>
                        <span class="value"><?php echo e($deliveryRequest->nama_pemesan); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">No. HP:</span>
                        <span class="value"><?php echo e($deliveryRequest->no_hp); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Sales:</span>
                        <span class="value"><?php echo e($deliveryRequest->salesforce); ?></span>
                    </div>
                </div>
                
                <div class="info-group">
                    <h4>Informasi Pengiriman</h4>
                    <div class="info-row">
                        <span class="label">Tanggal Delivery:</span>
                        <span class="value"><?php echo e($deliveryRequest->tanggal_delivery->format('d/m/Y')); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Jam Delivery:</span>
                        <span class="value"><?php echo e($deliveryRequest->jam_delivery); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Lokasi Delivery:</span>
                        <span class="value"><?php echo e($deliveryRequest->lokasi_delivery); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="info-column">
                <div class="info-group">
                    <h4>Informasi Kendaraan</h4>
                    <div class="info-row">
                        <span class="label">No. SPK:</span>
                        <span class="value"><?php echo e($deliveryRequest->no_spk); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Type Mobil:</span>
                        <span class="value"><?php echo e($deliveryRequest->type_mobil); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Warna:</span>
                        <span class="value"><?php echo e($deliveryRequest->warna); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Posisi Unit:</span>
                        <span class="value"><?php echo e($deliveryRequest->posisi_unit); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">No. Rangka:</span>
                        <span class="value"><?php echo e($deliveryRequest->no_rangka); ?></span>
                    </div>
                </div>
                
                <div class="info-group">
                    <h4>Informasi Pembayaran</h4>
                    <div class="info-row">
                        <span class="label">Cara Bayar:</span>
                        <span class="value"><?php echo e($deliveryRequest->cara_bayar); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Leasing:</span>
                        <span class="value"><?php echo e($deliveryRequest->leasing ?? '-'); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Status Transaksi:</span>
                        <span class="value"><?php echo e($deliveryRequest->status_transaksi); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if($deliveryRequest->catatan): ?>
        <div class="note-section">
            <h4>Catatan Sales</h4>
            <p><?php echo e($deliveryRequest->catatan); ?></p>
        </div>
        <?php endif; ?>
        
        <div class="action-section">
            <form action="<?php echo e(route('gudang.update_status', $deliveryRequest->id)); ?>" method="POST" id="updateStatusForm">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="status">Update Status</label>
                    <select name="status" id="status" required>
                        <option value="pending" <?php echo e(old('status', $deliveryRequest->status) == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="process" <?php echo e(old('status', $deliveryRequest->status) == 'process' ? 'selected' : ''); ?>>Proses</option>
                        <option value="completed" <?php echo e(old('status', $deliveryRequest->status) == 'completed' ? 'selected' : ''); ?>>Selesai</option>
                        <option value="terlambat" <?php echo e(old('status', $deliveryRequest->status) == 'terlambat' ? 'selected' : ''); ?>>Terlambat</option>
                    </select>
                </div>

                <?php if($deliveryRequest->status == 'terlambat' && ($deliveryRequest->rca_category || $deliveryRequest->rca_specific_cause)): ?>
                <div class="note-section rca-display">
                    <h4>Root Cause Analysis (RCA) - Data Tersimpan</h4>
                    <p><strong>Kategori:</strong> <?php echo e($deliveryRequest->rca_category ?? 'N/A'); ?></p>
                    <p><strong>Penyebab Spesifik:</strong> <?php echo e($deliveryRequest->rca_specific_cause ?? 'N/A'); ?></p>
                    <p><strong>Usulan Perbaikan:</strong> <?php echo e($deliveryRequest->rca_improvement ?? 'N/A'); ?></p>
                </div>
                <?php endif; ?>
                
                <div id="rca-form" style="display: <?php echo e(old('status', $deliveryRequest->status) == 'terlambat' ? 'block' : 'none'); ?>;">
                    <input type="hidden" name="rca_category" id="rca_category" value="<?php echo e(old('rca_category', $deliveryRequest->rca_category)); ?>">
                    
                    <div class="form-group">
                        <label for="rca_specific_cause">Penyebab Spesifik</label>
                        <select name="rca_specific_cause" id="rca_specific_cause">
                            <option value="">Pilih Penyebab</option>
                            <?php $__currentLoopData = $rcaSpecificCauses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cause): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cause); ?>" <?php echo e(old('rca_specific_cause', $deliveryRequest->rca_specific_cause) == $cause ? 'selected' : ''); ?>><?php echo e($cause); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group" id="other-cause-group" style="display: none;">
                        <label for="other_cause">Penyebab Lainnya (Tulis Manual)</label>
                        <input type="text" id="other_cause" placeholder="Masukkan penyebab spesifik lainnya..." maxlength="255">
                        <small style="color: #666; font-size: 11px;">Ketik penyebab spesifik yang tidak ada di dropdown</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="rca_improvement">Usulan Perbaikan (Opsional)</label>
                        <textarea name="rca_improvement" id="rca_improvement" rows="3" placeholder="Masukkan usulan perbaikan..."><?php echo e(old('rca_improvement', $deliveryRequest->rca_improvement)); ?></textarea>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="notes">Catatan Gudang (Opsional)</label>
                    <textarea name="notes" id="notes" rows="3" placeholder="Catatan tambahan dari gudang"><?php echo e(old('notes', $deliveryRequest->gudang_notes)); ?></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="actual_delivery_date">Tanggal Pengiriman Aktual</label>
                        <input type="date" name="actual_delivery_date" id="actual_delivery_date" value="<?php echo e(old('actual_delivery_date', $deliveryRequest->actual_delivery_date ? $deliveryRequest->actual_delivery_date->format('Y-m-d') : '')); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="actual_delivery_time">Jam Pengiriman Aktual</label>
                        <input type="time" name="actual_delivery_time" id="actual_delivery_time" value="<?php echo e(old('actual_delivery_time', $deliveryRequest->actual_delivery_time)); ?>">
                    </div>
                </div>
                
                <button type="submit" class="btn-submit">Update Status</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .detail-card { padding: 20px; }
    .status-badge { padding: 5px 15px; border-radius: 20px; font-size: 14px; font-weight: 500; }
    .status-badge.terlambat { background-color: #e74c3c; color: white; }
    .info-section { display: flex; flex-wrap: wrap; gap: 30px; margin-top: 20px; }
    .info-column { flex: 1; min-width: 300px; }
    .info-group { margin-bottom: 20px; }
    .info-group h4 { margin-bottom: 10px; padding-bottom: 5px; border-bottom: 1px solid #ddd; }
    .info-row { display: flex; margin-bottom: 8px; }
    .info-row .label { flex: 0 0 150px; font-weight: 500; }
    .info-row .value { flex: 1; }
    .note-section { margin: 20px 0; padding: 15px; background-color: #f9f9f9; border-radius: 5px; }
    .note-section h4 { margin-bottom: 10px; }
    .rca-display { background-color: #e8f5e8; border-left: 4px solid #4cd137; }
    .action-section { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; }
    .form-row { display: flex; gap: 15px; }
    .form-group { margin-bottom: 15px; flex: 1; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: 500; }
    .form-group select, .form-group input, .form-group textarea { width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
    .btn-submit { background-color: #d71920; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; }
    .error-highlight { border: 2px solid #e74c3c !important; background-color: #fdf2f2 !important; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const statusSelect = document.getElementById('status');
    const rcaForm = document.getElementById('rca-form');
    const specificCauseSelect = document.getElementById('rca_specific_cause');
    const rcaCategoryInput = document.getElementById('rca_category');
    const otherCauseGroup = document.getElementById('other-cause-group');
    const otherCauseInput = document.getElementById('other_cause');
    const form = document.getElementById('updateStatusForm');
    
    const rcaCausesMap = <?php echo json_encode($rcaCausesMap, 15, 512) ?>;

    function toggleRcaForm() {
        if (statusSelect.value === 'terlambat') {
            rcaForm.style.display = 'block';
            specificCauseSelect.required = true;
        } else {
            rcaForm.style.display = 'none';
            specificCauseSelect.required = false;
            otherCauseInput.required = false;
        }
    }

    function updateRcaCategory() {
        const selectedCause = specificCauseSelect.value;
        if (selectedCause && rcaCausesMap[selectedCause]) {
            rcaCategoryInput.value = rcaCausesMap[selectedCause];
        } else {
            rcaCategoryInput.value = '';
        }
        
        if (selectedCause === 'Lainnya') {
            otherCauseGroup.style.display = 'block';
            otherCauseInput.required = statusSelect.value === 'terlambat';
        } else {
            otherCauseGroup.style.display = 'none';
            otherCauseInput.required = false;
            otherCauseInput.value = '';
        }
    }

    statusSelect.addEventListener('change', toggleRcaForm);
    specificCauseSelect.addEventListener('change', updateRcaCategory);

    form.addEventListener('submit', function(e) {
        if (specificCauseSelect.value === 'Lainnya' && otherCauseInput.value.trim()) {
            let tempOption = document.createElement('option');
            tempOption.value = otherCauseInput.value.trim();
            tempOption.selected = true;
            specificCauseSelect.appendChild(tempOption);
        }
    });

    toggleRcaForm();
    updateRcaCategory();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/gudang/show_delivery.blade.php ENDPATH**/ ?>