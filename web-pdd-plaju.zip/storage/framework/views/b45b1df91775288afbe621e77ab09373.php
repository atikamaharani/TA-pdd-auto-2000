

<?php $__env->startSection('title', 'RCA Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>RCA Dashboard</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">RCA Dashboard</a></li>
        </ul>
     </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Filter Data Keterlambatan Aktif</h3>
        </div>
        <form method="GET" action="<?php echo e(route('admin.rca_dashboard')); ?>" id="filterForm" class="filter-form-inline">
            <div class="form-group">
                <label for="start_date">Tanggal Mulai:</label>
                 <input type="date" name="start_date" id="start_date" value="<?php echo e($startDate); ?>">
            </div>
            <div class="form-group">
                <label for="end_date">Tanggal Akhir:</label>
                <input type="date" name="end_date" id="end_date" value="<?php echo e($endDate); ?>">
            </div>
            <div class="form-group">
                 <button type="submit" class="btn-filter">Terapkan</button>
            </div>
             <a href="<?php echo e(route('admin.rca_report.download', ['start_date' => $startDate, 'end_date' => $endDate])); ?>" class="btn-download" 
                style="background-color: #ffffff; color: #342e37; border: 1px solid #dddddd; height: 36px; padding: 0 16px; border-radius: 5px; text-decoration: none; display: inline-flex; align-items: center; gap: 10px;">
                <i class='bx bxs-file-pdf' style="color: #d71920;"></i>
                <span class="text">Download PDF</span>
            </a>
            <a href="<?php echo e(route('admin.rca_history')); ?>" class="btn-history" 
                style="background-color: var(--blue); color: white; height: 36px; padding: 0 16px; border-radius: 5px; text-decoration: none; display: inline-flex; align-items: center; gap: 10px;">
                <i class='bx bx-history'></i>
                <span class="text">Lihat Histori</span>
            </a>
        </form>
    </div>
</div>

<ul class="box-info">
    <li>
        <i class='bx bxs-calendar-x'></i>
        <span class="text">
            <h3><?php echo e($lateCount); ?></h3>
             <p>Total Keterlambatan</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-truck'></i>
        <span class="text">
            <h3><?php echo e($totalDeliveries); ?></h3>
            <p>Total Pengiriman</p>
        </span>
    </li>
    <li>
        <i class='bx  bxs-pie-chart-alt-2'></i>
        <span class="text">
            <h3><?php echo e($totalDeliveries > 0 ? round(($lateCount / $totalDeliveries) * 100, 2) : 0); ?>%</h3>
            <p>Tingkat Keterlambatan</p>
        </span>
    </li>
</ul>

<div class="table-data">
    <div class="order" style="flex-basis: 58%;">
        <div class="head">
            <h3>Grafik Keterlambatan per Bulan</h3>
        </div>
         <div style="height:300px;">
            <canvas id="latesChart"></canvas>
        </div>
    </div>
    <div class="order" style="flex-basis: 38%;">
        <div class="head">
            <h3>Penyebab Keterlambatan Berdasarkan Kategori Fishbone (6M)</h3>
        </div>
        <div style="height:300px;">
            <canvas id="categoryChart"></canvas>
         </div>
    </div>
</div>

<div class="table-data" style="margin-top:20px;">
    <div class="order">
        <div class="head">
            <h3>Analisis Pareto Penyebab Keterlambatan</h3>
        </div>
        <div style="height:400px;">
            <canvas id="paretoChart"></canvas>
        </div>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Detail Pengiriman yang Pernah Terlambat</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Nama Pemesan</th>
                     <th>Sales</th>
                    <th>Tanggal Aktual</th>
                    <th>Kategori</th>
                    <th>Penyebab Spesifik</th>
                    <th>Status Saat Ini</th>
                </tr>
             </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $lates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $late): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.show_delivery', $late->id)); ?>"><?php echo e($late->no_spk); ?></a></td>
                         <td><?php echo e($late->nama_pemesan); ?></td>
                        <td><?php echo e($late->user->username); ?></td>
                        <td><?php echo e($late->actual_delivery_date ? $late->actual_delivery_date->format('d/m/Y') : 'N/A'); ?></td>
                        <td><?php echo e($late->rca_category ?? 'N/A'); ?></td>
                        <td><?php echo e($late->rca_specific_cause ?? 'N/A'); ?></td>
                        <td>
                            <?php if($late->status == 'completed'): ?>
                                <span class="status <?php echo e($late->is_rescheduled ? 'terlambat' : 'completed'); ?>">
                                    Selesai
                                </span>
                            <?php else: ?>
                                <span class="status <?php echo e($late->status); ?>"><?php echo e(ucfirst($late->status)); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" style="text-align: center;">Tidak ada data keterlambatan untuk periode ini.</td>
                     </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .filter-form-inline { display: flex; flex-wrap: wrap; gap: 15px; align-items: flex-end; }
    .filter-form-inline .form-group { display: flex; flex-direction: column; }
    .filter-form-inline label { margin-bottom: 5px; font-size: 13px; color: var(--dark-grey); }
    .filter-form-inline input, .filter-form-inline select { padding: 8px 10px; border-radius: 5px; border: 1px solid var(--grey); background-color: var(--light); font-size: 14px; min-width: 150px; }
    .filter-form-inline .btn-filter { padding: 9px 20px; background-color: var(--blue); color: var(--light); border: none; border-radius: 5px; cursor: pointer; font-size: 14px; }
    a { text-decoration: none; color: var(--blue); }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const categoryData = <?php echo json_encode($categoryCount, 15, 512) ?>;
    const categoryChartCtx = document.getElementById('categoryChart');
    if (categoryChartCtx && Object.keys(categoryData).length > 0) {
        const colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c'];
        new Chart(categoryChartCtx, {
            type: 'pie',
            data: {
                labels: Object.keys(categoryData),
                 datasets: [{
                    label: 'Jumlah',
                    data: Object.values(categoryData),
                    backgroundColor: colors.slice(0, Object.keys(categoryData).length),
                    borderWidth: 2,
                     borderColor: '#fff'
                }]
            },
            options: { 
                responsive: true, 
                maintainAspectRatio: false, 
                 plugins: { 
                    legend: { 
                        position: 'bottom',
                        labels: {
                             boxWidth: 15,
                            padding: 15
                        }
                    },
                     tooltip: {
                        callbacks: {
                            label: function(context) {
                                const total =  context.dataset.data.reduce((sum, value) => sum + value, 0);
                                const percentage = ((context.parsed / total) * 100).toFixed(1);
                                return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                            }
                        }
                    }
                } 
            }
        });
    }

    const latesChartData = <?php echo json_encode($chartData, 15, 512) ?>;
    const latesChartLabels = <?php echo json_encode($chartLabels, 15, 512) ?>;
    const latesChartCtx = document.getElementById('latesChart');
    if(latesChartCtx) {
        new Chart(latesChartCtx, {
            type: 'bar',
            data: {
                labels: latesChartLabels,
                datasets: [{
                    label: 'Jumlah Keterlambatan',
                     data: latesChartData,
                    backgroundColor: 'rgba(231, 76, 60, 0.5)',
                    borderColor: 'rgba(231, 76, 60, 1)',
                    borderWidth: 1
                }]
             },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
                 plugins: { legend: { display: false } }
            }
        });
    }

    const paretoChartData = <?php echo json_encode($paretoData, 15, 512) ?>;
    const paretoChartCtx = document.getElementById('paretoChart');
    if(paretoChartCtx && paretoChartData.length > 0) {
        const labels = paretoChartData.map(item => item.category);
        const counts = paretoChartData.map(item => item.count);
        const cumulatives = paretoChartData.map(item => item.cumulative);
        new Chart(paretoChartCtx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                         label: 'Jumlah Kasus',
                        data: counts,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        yAxisID: 'y',
                     },
                    {
                        label: 'Persentase Kumulatif (%)',
                        data: cumulatives,
                         type: 'line',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        fill: false,
                        yAxisID: 'y1',
                     }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                     y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                             text: 'Jumlah Kasus'
                        }
                    },
                    y1: {
                         beginAtZero: true,
                        max: 100,
                        position: 'right',
                        title: {
                             display: true,
                            text: 'Persentase Kumulatif (%)'
                        },
                        grid: {
                             drawOnChartArea: false,
                        }
                    }
                },
                 plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                         mode: 'index',
                        intersect: false
                    }
                }
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Artditya\Downloads\web-pdd-plaju (1)\web-pdd-plaju\resources\views/admin/rca_dashboard.blade.php ENDPATH**/ ?>