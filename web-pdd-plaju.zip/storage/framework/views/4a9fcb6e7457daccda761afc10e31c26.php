

<?php $__env->startSection('title', 'Notifikasi Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Notifikasi Admin</h1>
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
            </li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Notifikasi</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Semua Notifikasi</h3>
            <form action="<?php echo e(route('notifications.mark_all_read')); ?>" method="POST" style="margin-left: auto;">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-mark-all">
                    <i class='bx bx-check-double'></i>
                    Tandai Semua Dibaca
                </button>
            </form>
        </div>
        
        <div class="notification-list">
            <?php if(count($notifications) > 0): ?>
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="notification-item <?php echo e($notification->is_read ? 'read' : 'unread'); ?> <?php echo e(strpos(strtolower($notification->content), 'pending') !== false ? 'pending-notif' : (strpos(strtolower($notification->content), 'proses') !== false || strpos(strtolower($notification->content), 'process') !== false ? 'process-notif' : (strpos(strtolower($notification->content), 'selesai') !== false || strpos(strtolower($notification->content), 'completed') !== false ? 'completed-notif' : ''))); ?>">
                    <div class="notification-icon">
                        <i class='bx bxs-bell'></i>
                    </div>
                    <div class="notification-content">
                        <p><?php echo e($notification->content); ?></p>
                        <small><?php echo e($notification->created_at->diffForHumans()); ?></small>
                        <?php if($notification->related_id): ?>
                        <div class="notification-link">
                            <a href="<?php echo e(route('admin.delivery_data')); ?>?id=<?php echo e($notification->related_id); ?>" class="view-related">
                                <i class='bx bx-link'></i> Lihat Pengiriman
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if(!$notification->is_read): ?>
                    <div class="notification-action">
                        <a href="<?php echo e(route('notifications.mark_read', $notification->id)); ?>" class="mark-read">
                            <i class='bx bx-check'></i> Tandai Sudah Dibaca
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <div class="pagination">
                    <?php echo e($notifications->links()); ?>

                </div>
            <?php else: ?>
                <div class="notification-empty">
                    <i class='bx bx-bell-off'></i>
                    <p>Belum ada notifikasi</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .btn-mark-all {
        background-color: var(--blue);
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        font-size: 14px;
    }
    .notification-list { display: flex; flex-direction: column; gap: 10px; }
    .notification-item { display: flex; align-items: flex-start; padding: 15px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); background-color: #f9f9f9; }
    .notification-item.unread { background-color: #fff; border-left: 3px solid #d71920; }
    .notification-item.read { opacity: 0.8; }
    .notification-item.pending-notif { border-left: 3px solid #ff6b6b; }
    .notification-item.process-notif { border-left: 3px solid #ffce26; }
    .notification-item.completed-notif { border-left: 3px solid #4cd137; }
    .notification-icon { flex: 0 0 40px; height: 40px; display: flex; align-items: center; justify-content: center; color: #d71920; font-size: 24px; }
    .notification-content { flex: 1; margin: 0 15px; }
    .notification-content p { margin: 0 0 5px; }
    .notification-content small { color: #777; }
    .notification-link { margin-top: 5px; }
    .view-related { display: inline-flex; align-items: center; color: #3c91e6; font-size: 13px; text-decoration: none; }
    .view-related i { margin-right: 3px; }
    .notification-action { align-self: flex-end; }
    .mark-read { display: inline-flex; align-items: center; padding: 5px 10px; background-color: #3c91e6; color: white; border-radius: 4px; font-size: 12px; text-decoration: none; }
    .mark-read i { margin-right: 5px; }
    .notification-empty { display: flex; flex-direction: column; align-items: center; padding: 50px 0; color: #aaa; }
    .notification-empty i { font-size: 40px; margin-bottom: 10px; }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/admin/notifications.blade.php ENDPATH**/ ?>