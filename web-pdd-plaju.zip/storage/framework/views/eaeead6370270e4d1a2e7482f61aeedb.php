

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Permintaan Pengiriman Saya</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('sales.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Permintaan Pengiriman</a></li>
        </ul>
    </div>
    <a href="<?php echo e(route('sales.input_form')); ?>" class="btn-download">
        <i class='bx bxs-plus-circle'></i>
        <span class="text">Buat Permintaan Baru</span>
    </a>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Daftar Permintaan Saya</h3>
            <div class="search-container">
                <form action="<?php echo e(route('sales.deliveries')); ?>" method="GET">
                    <input type="text" name="search" placeholder="Cari (No SPK, Pemesan, Mobil...)" value="<?php echo e(request('search')); ?>">
                    <button type="submit"><i class='bx bx-search'></i></button>
                </form>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Nama Pemesan</th>
                    <th>Type Mobil</th>
                    <th>Jadwal Delivery</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deliveryRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($delivery->no_spk); ?></td>
                    <td><?php echo e($delivery->nama_pemesan); ?></td>
                    <td><?php echo e($delivery->type_mobil); ?></td>
                    <td><?php echo e($delivery->tanggal_delivery->format('d/m/Y')); ?> <?php echo e($delivery->jam_delivery); ?></td>
                    <td>
                        <?php if($delivery->status == 'completed'): ?>
                            <span class="status <?php echo e($delivery->is_rescheduled ? 'terlambat' : 'completed'); ?>">Selesai</span>
                        <?php else: ?>
                            <span class="status <?php echo e($delivery->status); ?>"><?php echo e(ucfirst($delivery->status)); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="action-buttons">
                        <a href="<?php echo e(route('sales.show_delivery', $delivery->id)); ?>" class="btn-action btn-view">Detail</a>
                        <?php if($delivery->status == 'pending'): ?>
                        <a href="<?php echo e(route('sales.edit_delivery', $delivery->id)); ?>" class="btn-action btn-edit">Edit</a>
                        <form action="<?php echo e(route('sales.destroy_delivery', $delivery->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus permintaan ini?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn-action btn-delete">Hapus</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="text-align: center;">Anda belum membuat permintaan pengiriman.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <div class="pagination">
            <?php echo e($deliveryRequests->appends(request()->query())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .action-buttons { display: flex; align-items: center; gap: 5px; }
    .btn-action { text-decoration: none; font-size: 12px; padding: 4px 8px; border-radius: 3px; }
    .btn-view { background-color: #3498db; color: white; }
    .btn-edit { background-color: #f1c40f; color: black; }
    .btn-delete { background-color: #e74c3c; color: white; border: none; cursor: pointer; font-family: inherit; }
    .search-container { display: flex; margin-left: auto; }
    .search-container form { display: flex; }
    .search-container input { width: 200px; padding: 8px 10px; border: 1px solid #ddd; border-radius: 20px 0 0 20px; outline: none; }
    .search-container button { padding: 0 10px; border: none; background: var(--red); color: white; border-radius: 0 20px 20px 0; cursor: pointer; }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Artditya\Downloads\web-pdd-plaju (1)\web-pdd-plaju\resources\views/sales/deliveries.blade.php ENDPATH**/ ?>