

<?php $__env->startSection('title', 'Histori Keterlambatan'); ?>

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Histori Pengiriman Terlambat</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="<?php echo e(route('admin.rca_dashboard')); ?>">RCA Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Histori</a></li>
        </ul>
    </div>
    <a href="<?php echo e(route('admin.rca_dashboard')); ?>" class="btn-download">
        <i class='bx bx-arrow-back'></i>
        <span class="text">Kembali ke RCA Dashboard</span>
    </a>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Filter Histori</h3>
        </div>
        <form method="GET" action="<?php echo e(route('admin.rca_history')); ?>" id="filterForm" class="filter-form-inline">
            <div class="form-group">
                <label for="start_date">Tanggal Mulai:</label>
                <input type="date" name="start_date" id="start_date" value="<?php echo e($startDate); ?>">
            </div>
            <div class="form-group">
                <label for="end_date">Tanggal Akhir:</label>
                <input type="date" name="end_date" id="end_date" value="<?php echo e($endDate); ?>">
            </div>
            <div class="form-group">
                <button type="submit" class="btn-filter">Terapkan</button>
            </div>
            <a href="<?php echo e(route('admin.rca_history.download', ['start_date' => $startDate, 'end_date' => $endDate])); ?>" class="btn-download" style="background-color: #ffffff; color: #342e37; border: 1px solid #dddddd; height: 36px; padding: 0 16px; border-radius: 5px; text-decoration: none; display: inline-flex; align-items: center; gap: 10px;">
                <i class='bx bxs-file-pdf' style="color: #d71920;"></i>
                <span class="text">Download PDF</span>
            </a>
        </form>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Rekam Jejak Pengiriman Terlambat</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Nama Pemesan</th>
                    <th>Sales</th>
                    <th>Tgl Aktual</th>
                    <th>Kategori RCA</th>
                    <th>Penyebab Spesifik</th>
                    <th>Status Saat Ini</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.show_delivery', $item->id)); ?>"><?php echo e($item->no_spk); ?></a></td>
                        <td><?php echo e($item->nama_pemesan); ?></td>
                        <td><?php echo e($item->user->username); ?></td>
                        <td><?php echo e($item->actual_delivery_date ? $item->actual_delivery_date->format('d/m/Y') : 'N/A'); ?></td>
                        <td><?php echo e($item->rca_category ?? 'N/A'); ?></td>
                        <td><?php echo e($item->rca_specific_cause ?? 'N/A'); ?></td>
                        <td>
                           <?php if($item->status == 'completed'): ?>
                                <span class="status terlambat">Selesai</span>
                            <?php else: ?>
                                <span class="status <?php echo e($item->status); ?>"><?php echo e(ucfirst($item->status)); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" style="text-align: center;">Tidak ada data histori keterlambatan untuk periode ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php echo e($history->appends(request()->query())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .filter-form-inline { display: flex; flex-wrap: wrap; gap: 15px; align-items: flex-end; }
    .filter-form-inline .form-group { display: flex; flex-direction: column; }
    .filter-form-inline label { margin-bottom: 5px; font-size: 13px; color: var(--dark-grey); }
    .filter-form-inline input { padding: 8px 10px; border-radius: 5px; border: 1px solid var(--grey); background-color: var(--light); font-size: 14px; min-width: 150px; }
    .filter-form-inline .btn-filter { padding: 9px 20px; background-color: var(--blue); color: var(--light); border: none; border-radius: 5px; cursor: pointer; font-size: 14px; }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Artditya\Downloads\web-pdd-plaju (1)\web-pdd-plaju\resources\views/admin/rca_history.blade.php ENDPATH**/ ?>