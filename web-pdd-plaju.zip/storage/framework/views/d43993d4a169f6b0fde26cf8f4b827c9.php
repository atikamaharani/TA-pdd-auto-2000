<?php if($paginator->hasPages()): ?>
    <div class="pagination-wrapper">
        <nav class="pagination-nav" role="navigation" aria-label="Pagination Navigation">
            <div class="pagination-info">
                <span class="pagination-text">
                    Menampilkan <?php echo e($paginator->firstItem()); ?> - <?php echo e($paginator->lastItem()); ?> dari <?php echo e($paginator->total()); ?> data
                </span>
            </div>
            
            <ul class="pagination-list">
                
                <?php if($paginator->onFirstPage()): ?>
                    <li class="pagination-item disabled">
                        <span class="pagination-link">
                            <i class='bx bx-chevron-left'></i>
                            <span class="pagination-text-desktop">Sebelumnya</span>
                        </span>
                    </li>
                <?php else: ?>
                    <li class="pagination-item">
                        <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pagination-link" rel="prev">
                            <i class='bx bx-chevron-left'></i>
                            <span class="pagination-text-desktop">Sebelumnya</span>
                        </a>
                    </li>
                <?php endif; ?>

                
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(is_string($element)): ?>
                        <li class="pagination-item disabled">
                            <span class="pagination-link"><?php echo e($element); ?></span>
                        </li>
                    <?php endif; ?>

                    
                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $paginator->currentPage()): ?>
                                <li class="pagination-item active">
                                    <span class="pagination-link"><?php echo e($page); ?></span>
                                </li>
                            <?php else: ?>
                                <li class="pagination-item">
                                    <a href="<?php echo e($url); ?>" class="pagination-link"><?php echo e($page); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php if($paginator->hasMorePages()): ?>
                    <li class="pagination-item">
                        <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="pagination-link" rel="next">
                            <span class="pagination-text-desktop">Selanjutnya</span>
                            <i class='bx bx-chevron-right'></i>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="pagination-item disabled">
                        <span class="pagination-link">
                            <span class="pagination-text-desktop">Selanjutnya</span>
                            <i class='bx bx-chevron-right'></i>
                        </span>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
<?php endif; ?><?php /**PATH C:\Users\Artditya\Downloads\web-pdd-plaju (1)\web-pdd-plaju\resources\views/custom-pagination.blade.php ENDPATH**/ ?>