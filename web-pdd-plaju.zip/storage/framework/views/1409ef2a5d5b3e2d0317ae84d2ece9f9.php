

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Log Aktivitas</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Log Aktivitas</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Aktivitas Sistem</h3>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Dari</th>
                    <th>Ke</th>
                    <th>Deskripsi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($activity->created_at->format('d/m/Y H:i')); ?></td>
                    <td><?php echo e($activity->fromUser->username ?? 'System'); ?></td>
                    <td>
                        <?php if($activity->to_user_id): ?>
                            <?php echo e($activity->toUser->username); ?>

                        <?php elseif($activity->to_role): ?>
                            <?php echo e(ucfirst($activity->to_role)); ?>

                        <?php else: ?>
                            System
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($activity->content); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <div class="pagination">
            <?php echo e($activities->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/admin/activity_log.blade.php ENDPATH**/ ?>