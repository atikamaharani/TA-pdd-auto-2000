<?php $__env->startSection('content'); ?>
    <?php if(isset($isReminderNeeded) && $isReminderNeeded): ?>
        <div class="alert alert-info">
            <i class='bx bx-info-circle'></i>
            <strong>Reminder:</strong> Anda belum membuat Delivery Request untuk pengiriman H+2 (Tanggal: <?php echo e(\Carbon\Carbon::parse($deliveryTargetDate)->format('d F Y')); ?>).
        </div>
    <?php endif; ?>

    <div class="head-title">
        <div class="left">
            <h1>Selamat Datang di Dashboard Sales</h1>
            <ul class="breadcrumb">
                <li><a href="<?php echo e(route('sales.dashboard')); ?>">Dashboard</a></li>
                <li><i class='bx bx-chevron-right'></i></li>
                <li><a class="active" href="#">Home</a></li>
            </ul>
        </div>
        <a href="<?php echo e(route('sales.input_form')); ?>" class="btn-download">
            <i class='bx bxs-plus-circle'></i>
            <span class="text">Input Delivery Request</span>
        </a>
    </div>

    <ul class="box-info">
        <li>
            <i class='bx bxs-edit'></i>
            <span class="text">
                <h3><?php echo e($statistics['total']); ?></h3>
                <p>Total Input</p>
            </span>
        </li>
        <li>
            <i class='bx bxs-time-five'></i>
            <span class="text">
                <h3><?php echo e($statistics['pending'] + $statistics['process']); ?></h3>
                <p>Dalam Proses</p>
            </span>
        </li>
        <li>
            <i class='bx bxs-check-circle'></i>
            <span class="text">
                <h3><?php echo e($statistics['completed']); ?></h3>
                <p>Selesai</p>
            </span>
        </li>
    </ul>

    <div class="table-data">
        <div class="order">
            <div class="head">
                <h3>Permintaan Pengiriman Saya</h3>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Pemesan</th>
                        <th>Type Mobil</th>
                        <th>Tanggal Delivery</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $myDeliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($delivery->nama_pemesan); ?></td>
                        <td><?php echo e($delivery->type_mobil); ?></td>
                        <td><?php echo e($delivery->tanggal_delivery->format('d/m/Y')); ?> <?php echo e($delivery->jam_delivery); ?></td>
                        <td>
                            <?php if($delivery->status == 'completed'): ?>
                                <span class="status <?php echo e($delivery->is_rescheduled ? 'terlambat' : 'completed'); ?>">Selesai</span>
                            <?php else: ?>
                                <span class="status <?php echo e($delivery->status); ?>"><?php echo e(ucfirst($delivery->status)); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">Tidak ada data pengiriman.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php if($totalMyDeliveries > 3): ?>
                <a href="<?php echo e(route('sales.deliveries')); ?>" class="view-all-link" style="display: block; text-align: right; margin-top: 10px; color: var(--blue); text-decoration: none; font-weight: 500;">Lihat Semua Pengiriman Saya &rarr;</a>
            <?php endif; ?>
        </div>

        <div class="todo">
            <div class="head">
                <h3>Notifikasi</h3>
            </div>
            <ul class="todo-list">
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="<?php echo e(strpos(strtolower($notification->content), 'pending') !== false ? 'not-completed' : (strpos(strtolower($notification->content), 'proses') !== false || strpos(strtolower($notification->content), 'process') !== false ? 'process' : (strpos(strtolower($notification->content), 'selesai') !== false || strpos(strtolower($notification->content), 'completed') !== false ? 'completed' : ($notification->is_read ? 'completed' : 'not-completed')))); ?>">
                    <p><?php echo e(Str::limit($notification->content, 50)); ?></p>
                    <i class='bx bx-check <?php echo e($notification->is_read ? "" : "bx-circle"); ?>'></i>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="not-completed">
                    <p>Belum ada notifikasi baru</p>
                </li>
                <?php endif; ?>
            </ul>
            <?php if($totalNotifications > 3): ?>
                <a href="<?php echo e(route('notifications.index')); ?>" class="view-all-link" style="display: block; text-align: right; margin-top: 10px; color: var(--blue); text-decoration: none; font-weight: 500;">Lihat Semua Notifikasi &rarr;</a>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/dashboard/sales.blade.php ENDPATH**/ ?>