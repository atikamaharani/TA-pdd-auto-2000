

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Statistik Input</h1>
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('sales.dashboard')); ?>">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Statistik Input</a></li>
        </ul>
    </div>
</div>


<div class="head-title" style="margin-top: 30px;">
    <div class="left">
        <h2>Status Input Pengiriman</h2>
        
        
    </div>
</div>

<ul class="box-info">
    <li>
        <i class='bx bxs-calendar-day'></i>
        <span class="text">
            <h3><?php echo e($dailyStats); ?></h3>
            <p>Input Hari Ini</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-calendar-month'></i>
        <span class="text">
            <h3><?php echo e($monthlyStats); ?></h3>
            <p>Input Bulan Ini</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-calendar'></i>
        <span class="text">
            <h3><?php echo e($yearlyStats); ?></h3>
            <p>Input Tahun Ini</p>
        </span>
    </li>
</ul>

<ul class="box-info">
    <li>
        <i class='bx bxs-time-five' style="background: var(--light-orange); color: var(--orange);"></i>
        <span class="text">
            <h3><?php echo e($pendingCount); ?></h3>
            <p>Pending</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-truck' style="background: var(--light-yellow); color: var(--yellow);"></i>
        <span class="text">
            <h3><?php echo e($processCount); ?></h3>
            <p>Proses</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-check-circle' style="background: var(--light-blue); color: var(--blue);"></i>
        <span class="text">
            <h3><?php echo e($completedCount); ?></h3>
            <p>Selesai</p>
        </span>
    </li>
</ul>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Top Type Kendaraan</h3>
        </div>
         <div style="width:100%; height:400px; margin: 20px 0;">
            <canvas id="carTypeChart"></canvas>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .head-title h2 { 
        font-size: 24px;
        font-weight: 600;
        margin-bottom: 10px;
        color: var(--dark);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const topCarTypesData = <?php echo json_encode($topCarTypes, 15, 512) ?>;
    
    const carTypeLabels = topCarTypesData.map(item => item.type_mobil);
    const carTypeCounts = topCarTypesData.map(item => item.total);

    const carTypeCtx = document.getElementById('carTypeChart');
    if(carTypeCtx) {
        // Hancurkan chart lama jika ada untuk mencegah duplikasi
        if (window.myCarTypeChart instanceof Chart) {
            window.myCarTypeChart.destroy();
        }
        window.myCarTypeChart = new Chart(carTypeCtx, {
            type: 'line',
            data: {
                labels: carTypeLabels,
                datasets: [{
                    label: 'Jumlah Input',
                    data: carTypeCounts,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 2,
                    pointRadius: 3,
                    pointBackgroundColor: 'rgba(75, 192, 192, 1)',
                    pointHoverRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Jumlah Input',
                            font: {
                                size: 14,
                                weight: 'bold'
                            },
                            color: document.body.classList.contains('dark') ? '#CFD8DC' : '#455A64'
                        },
                        grid: {
                            color: document.body.classList.contains('dark') ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)'
                        },
                        ticks: {
                            color: document.body.classList.contains('dark') ? '#B0BEC5' : '#546E7A',
                            precision: 0
                        }
                    },
                     x: {
                         title: {
                            display: true,
                            text: 'Type Mobil',
                             font: {
                                size: 14,
                                weight: 'bold'
                            },
                            color: document.body.classList.contains('dark') ? '#CFD8DC' : '#455A64'
                        },
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: document.body.classList.contains('dark') ? '#B0BEC5' : '#546E7A'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            color: document.body.classList.contains('dark') ? '#ECEFF1' : '#37474F',
                            font: {
                                size: 12
                            },
                            usePointStyle: true,
                            pointStyle: 'rectRounded'
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: document.body.classList.contains('dark') ? 'rgba(40, 40, 40, 0.9)' :'rgba(255, 255, 255, 0.95)',
                        titleColor: document.body.classList.contains('dark') ? '#ECEFF1' : '#263238',
                        bodyColor: document.body.classList.contains('dark') ? '#CFD8DC' : '#37474F',
                        borderColor: document.body.classList.contains('dark') ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.1)',
                        borderWidth: 1,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 12
                        },
                        padding: 10,
                        cornerRadius: 4,
                        displayColors: true,
                        boxPadding: 3
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                },
                 animation: {
                    duration: 800,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/sales/statistics.blade.php ENDPATH**/ ?>