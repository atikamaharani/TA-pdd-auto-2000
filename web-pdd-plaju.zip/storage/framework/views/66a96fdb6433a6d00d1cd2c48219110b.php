<?php $__env->startSection('title', 'Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Edit Profile</h1>
        <ul class="breadcrumb">
            <li>
                <?php if(Auth::user()->role == 'admin'): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                <?php elseif(Auth::user()->role == 'sales'): ?>
                    <a href="<?php echo e(route('sales.dashboard')); ?>">Dashboard</a>
                <?php elseif(Auth::user()->role == 'gudang'): ?>
                    <a href="<?php echo e(route('gudang.dashboard')); ?>">Dashboard</a>
                <?php endif; ?>
            </li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="<?php echo e(route('profile.show')); ?>">Profile</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Edit</a></li>
        </ul>
    </div>
    <a href="<?php echo e(route('profile.show')); ?>" class="btn-download" style="background-color: var(--blue) !important;">
        <i class='bx bx-arrow-back'></i>
        <span class="text">Kembali</span>
    </a>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Form Edit Profile</h3>
        </div>

        <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data" class="profile-form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="avatar-section">
                <div class="current-avatar">
                <img src="<?php echo e($user->avatar ? asset('storage/' . $user->avatar) : asset('images/default-avatar.png')); ?>" alt="Avatar" id="avatar-preview" class="avatar-img">
                </div>
                <div class="avatar-controls">
                    <div class="form-group">
                        <label for="avatar">Foto Profile (Opsional)</label>
                        <input type="file" id="avatar" name="avatar" accept="image/*" onchange="previewAvatar(this)">
                        <small>Format: JPG, PNG, GIF. Maksimal 2MB</small>
                         <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-message"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required value="<?php echo e(old('username', $user->username)); ?>">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error-message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required value="<?php echo e(old('email', $user->email)); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error-message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="password-section">
                <h4>Ubah Password (Opsional)</h4>
                <div class="form-row">
                    <div class="form-group">
                        <label for="current_password">Password Saat Ini</label>
                        <input type="password" id="current_password" name="current_password">
                        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-message"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Password Baru</label>
                        <input type="password" id="password" name="password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-message"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="password_confirmation">Konfirmasi Password Baru</label>
                        <input type="password" id="password_confirmation" name="password_confirmation">
                    </div>
                </div>
            </div>

            <div class="form-row">
                <button type="submit" class="btn-submit">Update Profile</button>
                <a href="<?php echo e(route('profile.show')); ?>" class="btn-cancel">Batal</a>
            </div>
        </form>

        <?php if($user->avatar): ?>
        <div style="margin-top: 15px; padding-top:15px; border-top: 1px solid #ddd;">
            <form action="<?php echo e(route('profile.remove_avatar')); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus avatar?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn-remove-avatar">
                    <i class='bx bx-trash'></i> Hapus Avatar Saat Ini
                </button>
            </form>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .profile-form { width: 100%; }
    .avatar-section { display: flex; align-items: flex-start; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #ddd; gap: 20px; }
    .current-avatar { flex-shrink: 0; }
    .avatar-img { width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 3px solid #ddd; }
    .avatar-controls { flex: 1; }
    .btn-remove-avatar { background-color: #e74c3c; color: white; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; font-size: 12px; margin-top: 10px; display: inline-flex; align-items: center; gap: 5px; }
    .password-section { margin: 30px 0; padding: 20px; background-color: #f8f9fa; border-radius: 5px; }
    .password-section h4 { margin-bottom: 15px; color: #333; }
    .form-row { display: flex; flex-wrap: wrap; margin-bottom: 15px; gap: 15px; }
    .form-group { flex: 1; min-width: 250px; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: 500; }
    .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; box-sizing: border-box; }
    .form-group small { color: #666; font-size: 12px; display: block; margin-top: 3px; }
    .error-message { color: #e74c3c; font-size: 12px; display: block; margin-top: 3px; }
    .btn-submit { background-color: #d71920; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; transition: background-color 0.3s; font-size: 14px; }
    .btn-submit:hover { background-color: #b5141a; }
    .btn-cancel { background-color: #6c757d; color: white; padding: 10px 20px; border-radius: 4px; text-decoration: none; font-size: 14px; display: inline-block; margin-left: 10px; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function previewAvatar(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('avatar-preview').src = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Atika Project TA PDD\web-pdd-plaju\resources\views/profile/edit.blade.php ENDPATH**/ ?>