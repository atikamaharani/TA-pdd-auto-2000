<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="head-title">
    <div class="left">
        <h1>Profile Saya</h1>
        <ul class="breadcrumb">
            <li>
                <?php if(Auth::user()->role == 'admin'): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                <?php elseif(Auth::user()->role == 'sales'): ?>
                    <a href="<?php echo e(route('sales.dashboard')); ?>">Dashboard</a>
                <?php elseif(Auth::user()->role == 'gudang'): ?>
                    <a href="<?php echo e(route('gudang.dashboard')); ?>">Dashboard</a>
                <?php endif; ?>
            </li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Profile</a></li>
        </ul>
    </div>
    <a href="<?php echo e(route('profile.edit')); ?>" class="btn-download">
        <i class='bx bx-edit'></i>
        <span class="text">Edit Profile</span>
    </a>
</div>

<div class="table-data">
    <div class="order profile-card">
        <div class="head">
            <h3>Informasi Profile</h3>
        </div>

        <div class="profile-content">
            <div class="avatar-section">
                <div class="avatar-container">
                <img src="<?php echo e($user->avatar ? asset('storage/' . $user->avatar) : asset('images/default-avatar.png')); ?>" alt="Avatar" class="avatar-img">
                </div>
                <div class="avatar-info">
                    <h4><?php echo e($user->username); ?></h4>
                    <span class="role-badge <?php echo e(strtolower($user->role)); ?>"><?php echo e(ucfirst($user->role)); ?></span>
                </div>
            </div>

            <div class="info-section">
                <div class="info-group">
                    <h4>Informasi Akun</h4>
                    <div class="info-row">
                        <span class="label">Username:</span>
                        <span class="value"><?php echo e($user->username); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Email:</span>
                        <span class="value"><?php echo e($user->email); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Role:</span>
                        <span class="value"><?php echo e(ucfirst($user->role)); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Status:</span>
                        <span class="value">
                            <?php if($user->is_active): ?>
                                <span class="status active">Aktif</span>
                            <?php else: ?>
                                <span class="status inactive">Tidak Aktif</span>
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="info-row">
                        <span class="label">Bergabung:</span>
                        <span class="value"><?php echo e($user->created_at->format('d/m/Y H:i')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .profile-card { padding: 20px; }
    .profile-content { margin-top: 20px; }
    .avatar-section { display: flex; align-items: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #ddd; }
    .avatar-container { margin-right: 20px; }
    .avatar-img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #ddd; }
    .avatar-info h4 { margin: 0 0 5px; font-size: 24px; }
    .role-badge { padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; text-transform: uppercase; }
    .role-badge.admin { background-color: #e74c3c; color: white; }
    .role-badge.sales { background-color: #3498db; color: white; }
    .role-badge.gudang { background-color: #f39c12; color: white; }
    .info-section { display: flex; flex-wrap: wrap; gap: 30px; }
    .info-group { flex: 1; min-width: 300px; }
    .info-group h4 { margin-bottom: 15px; padding-bottom: 5px; border-bottom: 1px solid #ddd; }
    .info-row { display: flex; margin-bottom: 10px; }
    .info-row .label { flex: 0 0 120px; font-weight: 500; }
    .info-row .value { flex: 1; }
    .status { padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; }
    .status.active { background-color: #d4edda; color: #155724; }
    .status.inactive { background-color: #f8d7da; color: #721c24; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Artditya\Downloads\web-pdd-plaju (1)\web-pdd-plaju\resources\views/profile/show.blade.php ENDPATH**/ ?>