<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SalesController;
use App\Http\Controllers\GudangController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ProfileController;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);

    Route::get('/forgot-password', [AuthController::class, 'showForgotPassword'])->name('forgot.password');
    Route::post('/forgot-password', [AuthController::class, 'resetPassword']);
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'show'])->name('profile.show');
    Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile/avatar', [ProfileController::class, 'removeAvatar'])->name('profile.remove_avatar');

    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::get('/notifications/latest', [NotificationController::class, 'getLatest'])->name('notifications.latest');
    Route::get('/notifications/initial-data', [NotificationController::class, 'getInitialData'])->name('notifications.initial_data');
    Route::get('/notifications/{id}/mark-read', [NotificationController::class, 'markAsRead'])->name('notifications.mark_read');
    Route::post('/notifications/mark-all-read', [NotificationController::class, 'markAllAsRead'])->name('notifications.mark_all_read');

    Route::middleware('admin')->prefix('admin')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'admin'])->name('admin.dashboard');
        Route::get('/sales-data', [AdminController::class, 'salesData'])->name('admin.sales_data');
        Route::get('/delivery-data', [AdminController::class, 'deliveryData'])->name('admin.delivery_data');
        Route::get('/activity-log', [AdminController::class, 'activityLog'])->name('admin.activity_log');
        Route::get('/notifications', [AdminController::class, 'notifications'])->name('admin.notifications');
        Route::get('/delivery/{id}', [AdminController::class, 'showDelivery'])->name('admin.show_delivery');

        Route::get('/rca-dashboard', [AdminController::class, 'rcaDashboard'])->name('admin.rca_dashboard');
        Route::get('/rca-report/download', [AdminController::class, 'downloadRcaReport'])->name('admin.rca_report.download');
        Route::get('/rca-history', [AdminController::class, 'rcaHistory'])->name('admin.rca_history');
        Route::get('/rca-history/download', [AdminController::class, 'downloadRcaHistoryReport'])->name('admin.rca_history.download');

        Route::get('/users', [AdminController::class, 'usersIndex'])->name('admin.users.index');
        Route::get('/users/create', [AdminController::class, 'usersCreate'])->name('admin.users.create');
        Route::post('/users', [AdminController::class, 'usersStore'])->name('admin.users.store');
        Route::get('/users/{user}/edit', [AdminController::class, 'usersEdit'])->name('admin.users.edit');
        Route::put('/users/{user}', [AdminController::class, 'usersUpdate'])->name('admin.users.update');
        Route::delete('/users/{user}', [AdminController::class, 'usersDestroy'])->name('admin.users.destroy');
    });

    Route::middleware('sales')->prefix('sales')->name('sales.')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'sales'])->name('dashboard');
        Route::get('/input-delivery', [SalesController::class, 'showInputForm'])->name('input_form');
        Route::post('/input-delivery', [SalesController::class, 'storeDeliveryRequest'])->name('store_delivery');
        Route::get('/deliveries', [SalesController::class, 'deliveries'])->name('deliveries');
        Route::get('/statistics', [SalesController::class, 'statistics'])->name('statistics');
        Route::get('/delivery/{id}', [SalesController::class, 'showDeliveryDetail'])->name('show_delivery');
        Route::get('/delivery/{id}/edit', [SalesController::class, 'edit'])->name('edit_delivery');
        Route::put('/delivery/{id}', [SalesController::class, 'update'])->name('update_delivery');
        Route::delete('/delivery/{id}', [SalesController::class, 'destroy'])->name('destroy_delivery');

        Route::get('/delivery/{id}/track', [SalesController::class, 'trackDelivery'])->name('track_delivery');
        Route::get('/monthly-report', [SalesController::class, 'monthlyReport'])->name('monthly_report');
    });

    Route::middleware('gudang')->prefix('gudang')->name('gudang.')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'gudang'])->name('dashboard');
        Route::get('/delivery-requests', [GudangController::class, 'deliveryRequests'])->name('delivery_requests');
        Route::get('/delivery/{id}', [GudangController::class, 'showDeliveryRequest'])->name('show_delivery');
        Route::post('/delivery/{id}/update', [GudangController::class, 'updateStatus'])->name('update_status');
        Route::get('/reports', [GudangController::class, 'generateReport'])->name('reports');
    });

    Route::post('/admin/delivery/{id}/update-status', [AdminController::class, 'updateDeliveryStatus'])->name('admin.delivery.updateStatus');

});