<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('delivery_requests', function (Blueprint $table) {
            $table->dropColumn(['rca_5why']);
            $table->string('rca_category')->nullable()->after('rca_reason');
            $table->string('rca_specific_cause')->nullable()->after('rca_category');
        });
    }

    public function down(): void
    {
        Schema::table('delivery_requests', function (Blueprint $table) {
            $table->text('rca_5why')->nullable()->after('rca_reason');
            $table->dropColumn(['rca_category', 'rca_specific_cause']);
        });
    }
};