<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('delivery_requests', function (Blueprint $table) {
            $table->text('rca_reason')->nullable()->after('gudang_notes');
            $table->text('rca_5why')->nullable()->after('rca_reason');
            $table->text('rca_improvement')->nullable()->after('rca_5why');
        });

        DB::statement("ALTER TABLE delivery_requests CHANGE COLUMN status status ENUM('pending', 'process', 'completed', 'terlambat') NOT NULL DEFAULT 'pending'");
    }

    public function down(): void
    {
        Schema::table('delivery_requests', function (Blueprint $table) {
            $table->dropColumn(['rca_reason', 'rca_5why', 'rca_improvement']);
        });

        DB::statement("ALTER TABLE delivery_requests CHANGE COLUMN status status ENUM('pending', 'process', 'completed') NOT NULL DEFAULT 'pending'");
    }
};