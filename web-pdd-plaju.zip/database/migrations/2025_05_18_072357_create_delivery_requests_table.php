<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('delivery_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained();
            $table->string('salesforce');
            $table->string('nama_pemesan');
            $table->string('no_hp');
            $table->string('no_spk');
            $table->string('type_mobil');
            $table->string('warna');
            $table->string('posisi_unit');
            $table->string('no_rangka');
            $table->string('cara_bayar');
            $table->string('leasing')->nullable();
            $table->string('status_transaksi');
            $table->date('tanggal_delivery');
            $table->string('jam_delivery');
            $table->string('lokasi_delivery');
            $table->text('catatan')->nullable();
            $table->enum('status', ['pending', 'process', 'completed'])->default('pending');
            $table->text('gudang_notes')->nullable();
            $table->date('actual_delivery_date')->nullable();
            $table->string('actual_delivery_time')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('delivery_requests');
    }
};