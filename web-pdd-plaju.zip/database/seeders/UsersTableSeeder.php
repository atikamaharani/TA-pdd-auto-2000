<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Admin
        User::create([
            'username' => 'admin',
            'email' => 'admin@pdd-auto2000.com',
            'password' => Hash::make('admin123'),
            'role' => 'admin',
            'is_active' => true,
        ]);

        // Sales
        User::create([
            'username' => 'sales',
            'email' => 'sales@pdd-auto2000.com',
            'password' => Hash::make('sales123'),
            'role' => 'sales',
            'is_active' => true,
        ]);

        // Gudang
        User::create([
            'username' => 'gudang',
            'email' => 'gudang@pdd-auto2000.com',
            'password' => Hash::make('gudang123'),
            'role' => 'gudang',
            'is_active' => true,
        ]);
    }
}