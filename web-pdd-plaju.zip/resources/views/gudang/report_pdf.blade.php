<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>{{ $title }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        .header h2 {
            margin: 5px 0;
            color: #d71920;
        }
        .header p {
            margin: 5px 0;
            font-size: 11px;
        }
        .company-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .meta-info {
            margin-bottom: 15px;
            font-size: 11px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-align: left;
            padding: 6px;
            font-size: 11px;
        }
        td {
            padding: 6px;
            font-size: 10px;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
        .status-pending {
            color: #e74c3c;
            font-weight: bold;
        }
        .status-process {
            color: #f39c12;
            font-weight: bold;
        }
        .status-completed {
            color: #27ae60;
            font-weight: bold;
        }
        .status-completed-late {
            color: #c0392b;
            font-weight: bold;
        }
        .status-terlambat {
            color: #e74c3c;
            font-weight: bold;
        }
        .footer {
            margin-top: 30px;
            font-size: 9px;
            text-align: left;
            color: #555;
        }
        .summary {
            margin-top: 15px;
        }
        .summary table {
            width: 300px;
            margin-left: auto;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="company-name">PDD AUTO</div>
        <h2>{{ $title }}</h2>
        <p>Jl. Kapten Arivai No. 1, Plaju, Palembang</p>
    </div>
    
    <div class="meta-info">
        <table>
            <tr>
                <td width="120"><strong>Tanggal Cetak</strong></td>
                <td>: {{ $date }}</td>
            </tr>
            <tr>
                <td><strong>Periode</strong></td>
                <td>: {{ date('d/m/Y', strtotime($startDate)) }} - {{ date('d/m/Y', strtotime($endDate)) }}</td>
            </tr>
            <tr>
                <td><strong>Dicetak Oleh</strong></td>
                <td>: {{ $user->username }}</td>
            </tr>
        </table>
    </div>
    
    <table>
        <thead>
            <tr>
                <th width="5%">No.</th>
                <th width="15%">No SPK</th>
                <th width="20%">Nama Pemesan</th>
                <th width="15%">Type Mobil</th>
                <th width="15%">Tanggal Delivery</th>
                <th width="15%">Sales</th>
                <th width="15%">Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse($deliveries as $index => $delivery)
            <tr>
                <td class="text-center">{{ $index + 1 }}</td>
                <td>{{ $delivery->no_spk }}</td>
                <td>{{ $delivery->nama_pemesan }}</td>
                <td>{{ $delivery->type_mobil }}</td>
                <td>{{ $delivery->tanggal_delivery->format('d/m/Y') }} {{ $delivery->jam_delivery }}</td>
                <td>{{ $delivery->user->username }}</td>
                <td>
                    @if($delivery->status == 'completed')
                        @if($delivery->is_rescheduled)
                            <span class="status-completed-late">Selesai*</span>
                        @else
                            <span class="status-completed">Selesai</span>
                        @endif
                    @elseif($delivery->status == 'terlambat')
                        <span class="status-terlambat">Terlambat</span>
                    @else
                        <span class="status-{{$delivery->status}}">{{ ucfirst($delivery->status) }}</span>
                    @endif
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7" class="text-center">Tidak ada data pengiriman dalam periode ini</td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <div class="summary">
        <table>
            <tr>
                <th>Status</th>
                <th class="text-center">Jumlah</th>
            </tr>
            <tr>
                <td>Pending</td>
                <td class="text-center">{{ $deliveries->where('status', 'pending')->count() }}</td>
            </tr>
            <tr>
                <td>Proses</td>
                <td class="text-center">{{ $deliveries->where('status', 'process')->count() }}</td>
            </tr>
            <tr>
                <td>Selesai</td>
                <td class="text-center">{{ $deliveries->where('status', 'completed')->count() }}</td>
            </tr>
            <tr>
                <th>Total Pengiriman</th>
                <th class="text-center">{{ $deliveries->count() }}</th>
            </tr>
        </table>
    </div>

    <div class="footer">
        @if($deliveries->where('is_rescheduled', true)->where('status', 'completed')->count() > 0)
            <p>* Menandakan pengiriman selesai namun pernah dijadwalkan ulang (reschedule).</p>
        @endif
    </div>

</body>
</html>