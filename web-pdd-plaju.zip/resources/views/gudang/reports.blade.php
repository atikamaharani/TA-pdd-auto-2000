@extends('layouts.app')

@section('title', 'Laporan Pengiriman')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Laporan Pengiriman</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('gudang.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Laporan Pengiriman</a></li>
        </ul>
    </div>
    
    <a href="{{ route('gudang.reports') }}?download=true&start_date={{ $startDate }}&end_date={{ $endDate }}" class="btn-download">
        <i class='bx bxs-file-pdf'></i>
        <span class="text">Download PDF</span>
    </a>
</div>

@if(session('error'))
<div class="alert alert-error">
    {{ session('error') }}
</div>
@endif

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Filter Laporan</h3>
        </div>
        
        <form action="{{ route('gudang.reports') }}" method="GET" class="filter-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="start_date">Tanggal Mulai</label>
                    <input type="date" id="start_date" name="start_date" value="{{ $startDate }}">
                </div>
                
                <div class="form-group">
                    <label for="end_date">Tanggal Akhir</label>
                    <input type="date" id="end_date" name="end_date" value="{{ $endDate }}">
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn-filter">Filter</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Laporan Pengiriman: {{ date('d/m/Y', strtotime($startDate)) }} - {{ date('d/m/Y', strtotime($endDate)) }}</h3>
            <div class="summary-info">
                <span>Total: {{ $deliveries->count() }}</span> |
                <span class="status pending">Pending: {{ $deliveries->where('status', 'pending')->count() }}</span> | 
                <span class="status process">Proses: {{ $deliveries->where('status', 'process')->count() }}</span> |
                <span class="status completed">Selesai: {{ $deliveries->where('status', 'completed')->count() }}</span>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Pemesan</th>
                    <th>Type Mobil</th>
                    <th>Tanggal Delivery</th>
                    <th>Sales</th>
                    <th>Status</th>
                    <th>Pengiriman Aktual</th>
                </tr>
            </thead>
            <tbody>
                @forelse($deliveries as $delivery)
                <tr>
                    <td>{{ $delivery->no_spk }}</td>
                    <td>{{ $delivery->nama_pemesan }}</td>
                    <td>{{ $delivery->type_mobil }}</td>
                    <td>{{ $delivery->tanggal_delivery->format('d/m/Y') }} {{ $delivery->jam_delivery }}</td>
                    <td>{{ $delivery->user->username }}</td>
                    <td>
                        @if($delivery->status == 'completed')
                            <span class="status {{ $delivery->is_rescheduled ? 'terlambat' : 'completed' }}">Selesai</span>
                        @else
                            <span class="status {{ $delivery->status }}">{{ ucfirst($delivery->status) }}</span>
                        @endif
                    </td>
                    <td>
                        @if($delivery->actual_delivery_date)
                            {{ $delivery->actual_delivery_date->format('d/m/Y') }}
                            @if($delivery->actual_delivery_time)
                                {{ $delivery->actual_delivery_time }}
                            @endif
                        @else
                            -
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="text-center">Tidak ada data pengiriman dalam periode ini</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

@section('css')
<style>
    .filter-form {
        margin-bottom: 20px;
    }
    .form-row {
        display: flex;
        gap: 15px;
        align-items: flex-end;
    }
    .form-group {
        flex: 1;
    }
    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
    }
    .form-group input {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
    .btn-filter {
        background-color: #3c91e6;
        color: white;
        border: none;
        padding: 9px 20px;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn-filter:hover {
        background-color: #2980b9;
    }
    .status {
        padding: 2px 10px;
        border-radius: 20px;
        font-size: 12px;
    }
    .status.pending {
        background-color: #ff6b6b;
        color: white;
    }
    .status.process {
        background-color: #ffce26;
        color: black;
    }
    .status.completed {
        background-color: #4cd137;
        color: white;
    }
    .text-center {
        text-align: center;
    }
    .summary-info {
        font-size: 13px;
    }
    .summary-info .status {
        padding: 2px 5px;
        font-size: 11px;
    }
    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 5px;
    }
    .alert-error {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
</style>
@endsection