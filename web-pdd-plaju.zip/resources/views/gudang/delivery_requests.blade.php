@extends('layouts.app')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Delivery Requests</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('gudang.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Delivery Requests</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Daftar Permintaan Pengiriman</h3>
            <div class="search-container">
                <form action="{{ route('gudang.delivery_requests') }}" method="GET">
                    <input type="text" name="search" placeholder="Cari (No SPK, Pemesan, Mobil...)" value="{{ request('search') }}">
                    <button type="submit"><i class='bx bx-search'></i></button>
                </form>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Nama Pemesan</th>
                    <th>Type Mobil</th>
                    <th>Sales</th>
                    <th>Jadwal Delivery</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($deliveryRequests as $request)
                <tr>
                    <td>{{ $request->no_spk }}</td>
                    <td>{{ $request->nama_pemesan }}</td>
                    <td>{{ $request->type_mobil }}</td>
                    <td>{{ $request->user->username }}</td>
                    <td>{{ $request->tanggal_delivery->format('d/m/Y') }} {{ $request->jam_delivery }}</td>
                    <td>
                        @if($request->status == 'completed')
                            <span class="status {{ $request->is_rescheduled ? 'terlambat' : 'completed' }}">Selesai</span>
                        @else
                            <span class="status {{ $request->status }}">{{ ucfirst($request->status) }}</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('gudang.show_delivery', $request->id) }}" class="btn-action btn-view">
                            <i class='bx bx-show'></i> Detail
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align: center;">Tidak ada data permintaan.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
        
        <div class="pagination">
            {{ $deliveryRequests->appends(request()->query())->links() }}
        </div>
    </div>
</div>
@endsection

@section('css')
<style>
    .search-container { display: flex; margin-left: auto; }
    .search-container form { display: flex; }
    .search-container input { width: 200px; padding: 8px 10px; border: 1px solid #ddd; border-radius: 20px 0 0 20px; outline: none; }
    .search-container button { padding: 0 10px; border: none; background: var(--red); color: white; border-radius: 0 20px 20px 0; cursor: pointer; }
    .btn-action { padding: 4px 8px; border-radius: 4px; font-size: 12px; display: inline-flex; align-items: center; gap: 4px; text-decoration: none; }
    .btn-view { background-color: #3498db; color: white; }
</style>
@endsection