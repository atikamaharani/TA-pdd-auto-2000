<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>{{ $title }}</title>
    <style>
        body { 
            font-family: 'Helvetica', sans-serif; 
            font-size: 10px; 
            line-height: 1.4;
        }
        .header { 
            text-align: center; 
            margin-bottom: 25px; 
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .header h2 {
            margin-bottom: 5px;
        }
        .header p {
            margin: 0;
            font-size: 12px;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        th, td { 
            border: 1px solid #ccc; 
            padding: 8px; 
            text-align: left; 
            vertical-align: top;
            word-wrap: break-word;
        }
        th { 
            background-color: #f2f2f2; 
            font-weight: bold; 
        }
        .page-break {
            page-break-after: always;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Laporan Root Cause Analysis (RCA) Keterlambatan</h2>
        <p>Periode: {{ $period }}</p>
        <p>Dicetak pada: {{ date('d F Y') }}</p>
    </div>
    <table>
        <thead>
            <tr>
                <th style="width: 5%;">No.</th>
                <th style="width: 12%;">No SPK</th>
                <th style="width: 15%;">Pemesan</th>
                <th style="width: 12%;">Sales</th>
                <th style="width: 10%;">Kategori</th>
                <th style="width: 18%;">Penyebab Spesifik</th>
                <th style="width: 28%;">Usulan Perbaikan</th>
            </tr>
        </thead>
        <tbody>
            @forelse($lates as $index => $late)
            <tr>
                <td style="text-align: center;">{{ $index + 1 }}</td>
                <td>
                    {{ $late->no_spk }}<br>
                    <small>Tgl Aktual: {{ $late->actual_delivery_date ? \Carbon\Carbon::parse($late->actual_delivery_date)->format('d/m/Y') : 'N/A' }}</small>
                </td>
                <td>{{ $late->nama_pemesan }}</td>
                <td>{{ $late->user->username }}</td>
                <td>{{ $late->rca_category ?? 'N/A' }}</td>
                <td>{{ $late->rca_specific_cause ?? 'N/A' }}</td>
                <td>{{ $late->rca_improvement ?? 'N/A' }}</td>
            </tr>
            @empty
            <tr>
                <td colspan="7" style="text-align: center; padding: 20px;">Tidak ada data keterlambatan untuk periode ini.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>