@extends('layouts.app')

@section('title', 'Histori Keterlambatan')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Histori Pengiriman Terlambat</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="{{ route('admin.rca_dashboard') }}">RCA Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Histori</a></li>
        </ul>
    </div>
    <a href="{{ route('admin.rca_dashboard') }}" class="btn-download">
        <i class='bx bx-arrow-back'></i>
        <span class="text">Kembali ke RCA Dashboard</span>
    </a>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Filter Histori</h3>
        </div>
        <form method="GET" action="{{ route('admin.rca_history') }}" id="filterForm" class="filter-form-inline">
            <div class="form-group">
                <label for="start_date">Tanggal Mulai:</label>
                <input type="date" name="start_date" id="start_date" value="{{ $startDate }}">
            </div>
            <div class="form-group">
                <label for="end_date">Tanggal Akhir:</label>
                <input type="date" name="end_date" id="end_date" value="{{ $endDate }}">
            </div>
            <div class="form-group">
                <button type="submit" class="btn-filter">Terapkan</button>
            </div>
            <a href="{{ route('admin.rca_history.download', ['start_date' => $startDate, 'end_date' => $endDate]) }}" class="btn-download" style="background-color: #ffffff; color: #342e37; border: 1px solid #dddddd; height: 36px; padding: 0 16px; border-radius: 5px; text-decoration: none; display: inline-flex; align-items: center; gap: 10px;">
                <i class='bx bxs-file-pdf' style="color: #d71920;"></i>
                <span class="text">Download PDF</span>
            </a>
        </form>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Rekam Jejak Pengiriman Terlambat</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Nama Pemesan</th>
                    <th>Sales</th>
                    <th>Tgl Aktual</th>
                    <th>Kategori RCA</th>
                    <th>Penyebab Spesifik</th>
                    <th>Status Saat Ini</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($history as $item)
                    <tr>
                        <td><a href="{{ route('admin.show_delivery', $item->id) }}">{{ $item->no_spk }}</a></td>
                        <td>{{ $item->nama_pemesan }}</td>
                        <td>{{ $item->user->username }}</td>
                        <td>{{ $item->actual_delivery_date ? $item->actual_delivery_date->format('d/m/Y') : 'N/A' }}</td>
                        <td>{{ $item->rca_category ?? 'N/A' }}</td>
                        <td>{{ $item->rca_specific_cause ?? 'N/A' }}</td>
                        <td>
                           @if($item->status == 'completed')
                                <span class="status terlambat">Selesai</span>
                            @else
                                <span class="status {{ $item->status }}">{{ ucfirst($item->status) }}</span>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" style="text-align: center;">Tidak ada data histori keterlambatan untuk periode ini.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
        <div class="pagination">
            {{ $history->appends(request()->query())->links() }}
        </div>
    </div>
</div>
@endsection

@section('css')
<style>
    .filter-form-inline { display: flex; flex-wrap: wrap; gap: 15px; align-items: flex-end; }
    .filter-form-inline .form-group { display: flex; flex-direction: column; }
    .filter-form-inline label { margin-bottom: 5px; font-size: 13px; color: var(--dark-grey); }
    .filter-form-inline input { padding: 8px 10px; border-radius: 5px; border: 1px solid var(--grey); background-color: var(--light); font-size: 14px; min-width: 150px; }
    .filter-form-inline .btn-filter { padding: 9px 20px; background-color: var(--blue); color: var(--light); border: none; border-radius: 5px; cursor: pointer; font-size: 14px; }
</style>
@endsection