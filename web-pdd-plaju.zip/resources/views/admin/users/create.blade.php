@extends('layouts.app')

@section('title', 'Tambah Karyawan')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Tambah Karyawan Baru</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="{{ route('admin.users.index') }}">Data Karyawan</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Tambah</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Form Tambah Karyawan</h3>
        </div>
        <form action="{{ route('admin.users.store') }}" method="POST" class="form-horizontal">
            @csrf
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="{{ old('username') }}" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="{{ old('email') }}" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select id="role" name="role" required>
                    <option value="">Pilih Role</option>
                    <option value="admin" {{ old('role') == 'admin' ? 'selected' : '' }}>Admin</option>
                    <option value="sales" {{ old('role') == 'sales' ? 'selected' : '' }}>Sales</option>
                    <option value="gudang" {{ old('role') == 'gudang' ? 'selected' : '' }}>Gudang</option>
                </select>
            </div>
            <div class="form-group form-buttons">
                <button type="submit" class="btn-submit">Simpan</button>
                <a href="{{ route('admin.users.index') }}" class="btn-cancel">Batal</a>
            </div>
        </form>
    </div>
</div>
@endsection

@section('css')
<style>
    .form-horizontal .form-group { margin-bottom: 15px; }
    .form-horizontal label { display: block; margin-bottom: 5px; font-weight: 500; }
    .form-horizontal input, .form-horizontal select { width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
    .form-buttons { margin-top: 20px; display: flex; gap: 10px; }
    .btn-submit, .btn-cancel { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; color: white; text-decoration: none; }
    .btn-submit { background-color: var(--red); }
    .btn-cancel { background-color: #6c757d; }
</style>
@endsection