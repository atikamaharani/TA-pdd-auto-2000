@extends('layouts.app')

@section('title', 'Edit Karyawan')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Edit Karyawan: {{ $user->username }}</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="{{ route('admin.users.index') }}">Data Karyawan</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Edit</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Form Edit Karyawan</h3>
        </div>
        <form action="{{ route('admin.users.update', $user->id) }}" method="POST" class="form-horizontal">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="{{ old('username', $user->username) }}" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="{{ old('email', $user->email) }}" required>
            </div>
            <div class="form-group">
                <label for="password">Password Baru (Opsional)</label>
                <input type="password" id="password" name="password">
                <small>Kosongkan jika tidak ingin mengubah password.</small>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select id="role" name="role" required>
                    <option value="admin" {{ old('role', $user->role) == 'admin' ? 'selected' : '' }}>Admin</option>
                    <option value="sales" {{ old('role', $user->role) == 'sales' ? 'selected' : '' }}>Sales</option>
                    <option value="gudang" {{ old('role', $user->role) == 'gudang' ? 'selected' : '' }}>Gudang</option>
                </select>
            </div>
            <div class="form-group">
                <label for="is_active">Status</label>
                <select id="is_active" name="is_active" required>
                    <option value="1" {{ old('is_active', $user->is_active) == 1 ? 'selected' : '' }}>Aktif</option>
                    <option value="0" {{ old('is_active', $user->is_active) == 0 ? 'selected' : '' }}>Tidak Aktif</option>
                </select>
            </div>
            <div class="form-group form-buttons">
                <button type="submit" class="btn-submit">Update</button>
                <a href="{{ route('admin.users.index') }}" class="btn-cancel">Batal</a>
            </div>
        </form>
    </div>
</div>
@endsection

@section('css')
<style>
    .form-horizontal .form-group { margin-bottom: 15px; }
    .form-horizontal label { display: block; margin-bottom: 5px; font-weight: 500; }
    .form-horizontal input, .form-horizontal select { width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
    .form-horizontal small { font-size: 12px; color: #6c757d; }
    .form-buttons { margin-top: 20px; display: flex; gap: 10px; }
    .btn-submit, .btn-cancel { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; color: white; text-decoration: none; }
    .btn-submit { background-color: var(--red); }
    .btn-cancel { background-color: #6c757d; }
</style>
@endsection