@extends('layouts.app')

@section('title', 'Data Karyawan')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Data Karyawan</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Data Karyawan</a></li>
        </ul>
    </div>
    <a href="{{ route('admin.users.create') }}" class="btn-download">
        <i class='bx bxs-plus-circle'></i>
        <span class="text">Tambah Karyawan</span>
    </a>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Daftar Karyawan</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $user)
                <tr>
                    <td>{{ $user->username }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ ucfirst($user->role) }}</td>
                    <td>
                        <span class="status {{ $user->is_active ? 'completed' : 'pending' }}">
                            {{ $user->is_active ? 'Aktif' : 'Tidak Aktif' }}
                        </span>
                    </td>
                    <td class="action-buttons">
                        <a href="{{ route('admin.users.edit', $user->id) }}" class="btn-edit">Edit</a>
                        @if(Auth::id() !== $user->id)
                        <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST" onsubmit="return confirm('Anda yakin ingin menghapus user ini?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-delete">Hapus</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5" class="text-center">Tidak ada data karyawan.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
        <div class="pagination">
            {{ $users->links() }}
        </div>
    </div>
</div>
@endsection

@section('css')
<style>
    .action-buttons {
        display: flex;
        gap: 5px;
    }
    .btn-edit, .btn-delete {
        padding: 5px 10px;
        border-radius: 5px;
        text-decoration: none;
        color: white;
        border: none;
        cursor: pointer;
    }
    .btn-edit { background-color: #3c91e6; }
    .btn-delete { background-color: #e74c3c; }
    .text-center { text-align: center; }
</style>
@endsection