@extends('layouts.app')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Log Aktivitas</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Log Aktivitas</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Aktivitas Sistem</h3>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Dari</th>
                    <th>Ke</th>
                    <th>Deskripsi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($activities as $activity)
                <tr>
                    <td>{{ $activity->created_at->format('d/m/Y H:i') }}</td>
                    <td>{{ $activity->fromUser->username ?? 'System' }}</td>
                    <td>
                        @if($activity->to_user_id)
                            {{ $activity->toUser->username }}
                        @elseif($activity->to_role)
                            {{ ucfirst($activity->to_role) }}
                        @else
                            System
                        @endif
                    </td>
                    <td>{{ $activity->content }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        
        <div class="pagination">
            {{ $activities->links() }}
        </div>
    </div>
</div>
@endsection