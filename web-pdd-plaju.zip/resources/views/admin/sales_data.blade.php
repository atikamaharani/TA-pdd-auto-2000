@extends('layouts.app')

@section('title', 'Data Sales & Karyawan')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Data Sales & Karyawan</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Data Sales & Karyawan</a></li>
        </ul>
    </div>
    <a href="{{ route('admin.users.create') }}" class="btn-download">
        <i class='bx bxs-plus-circle'></i>
        <span class="text">Tambah Karyawan</span>
    </a>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Daftar Karyawan</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $user)
                <tr>
                    <td>{{ $user->username }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ ucfirst($user->role) }}</td>
                    <td>
                        <span class="status {{ $user->is_active ? 'completed' : 'pending' }}">
                            {{ $user->is_active ? 'Aktif' : 'Tidak Aktif' }}
                        </span>
                    </td>
                    <td class="action-buttons">
                        <a href="{{ route('admin.users.edit', $user->id) }}" class="btn-edit">Edit</a>
                        @if(Auth::id() !== $user->id)
                        <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST" onsubmit="return confirm('Anda yakin ingin menghapus user ini?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-delete">Hapus</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5" class="text-center">Tidak ada data karyawan.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
        <div class="pagination">
            {{ $users->links() }}
        </div>
    </div>
</div>

<div class="table-data" style="margin-top: 20px;">
    <div class="order">
        <div class="head">
            <h3>Filter Statistik Input</h3>
        </div>
        <form method="GET" action="{{ route('admin.sales_data') }}" id="filterForm" class="filter-form-inline">
            <div class="form-group">
                <label for="type">Tampilkan Berdasarkan:</label>
                <select name="type" id="type">
                    <option value="spv" {{ $selectedType == 'spv' ? 'selected' : '' }}>Sales SPV</option>
                    <option value="salesforce" {{ $selectedType == 'salesforce' ? 'selected' : '' }}>Salesforce</option>
                </select>
            </div>
            <div class="form-group">
                <label for="year">Pilih Tahun:</label>
                <select name="year" id="year">
                    @foreach($years as $year)
                        <option value="{{ $year }}" {{ $selectedYear == $year ? 'selected' : '' }}>{{ $year }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn-filter">Terapkan Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="table-data" style="margin-top: 20px;">
    <div class="order">
        <div class="head">
            <h3>Statistik Input (Tahun {{ $selectedYear }})</h3>
        </div>
        <div style="width:100%; height:450px; margin: 20px 0;">
            <canvas id="salesInputChart"></canvas>
        </div>
    </div>
</div>

<div class="table-data" style="margin-top: 20px;">
    <div class="order">
        <div class="head">
            <h3>Rekap Input (Total Keseluruhan)</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Total Input</th>
                    <th>Pending</th>
                    <th>Proses</th>
                    <th>Selesai</th>
                </tr>
            </thead>
            <tbody>
                @forelse($stats as $stat)
                <tr>
                    <td>{{ $stat['name'] }}</td>
                    <td>{{ $stat['total'] }}</td>
                    <td>{{ $stat['pending'] }}</td>
                    <td>{{ $stat['process'] }}</td>
                    <td>{{ $stat['completed'] }}</td>
                </tr>
                @empty
                 <tr>
                    <td colspan="5" style="text-align:center;">Tidak ada data untuk ditampilkan.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

@section('css')
<style>
    .filter-form-inline { display: flex; flex-wrap: wrap; gap: 15px; align-items: flex-end; padding: 15px; background-color: var(--light); border-radius: 8px; margin-bottom: 20px; }
    .filter-form-inline .form-group { display: flex; flex-direction: column; }
    .filter-form-inline label { margin-bottom: 5px; font-size: 13px; color: var(--dark-grey); }
    .filter-form-inline select { padding: 8px 10px; border-radius: 5px; border: 1px solid var(--grey); background-color: var(--light-blue); color: var(--dark); font-size: 14px; min-width: 150px; }
    .filter-form-inline .btn-filter { padding: 9px 20px; background-color: var(--blue); color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; transition: background-color 0.3s ease; }
    .filter-form-inline .btn-filter:hover { background-color: #0056b3; }
    table {width: 100%; border-collapse: collapse;}
    table th {padding: 12px 10px; font-size: 14px; text-align: left; border-bottom: 1px solid var(--grey);}
    table td {padding: 12px 10px; font-size: 14px;}
    table tr:hover {background-color: var(--grey);}
    .action-buttons { display: flex; gap: 5px; }
    .btn-edit, .btn-delete { padding: 5px 10px; border-radius: 5px; text-decoration: none; color: white; border: none; cursor: pointer; }
    .btn-edit { background-color: #3c91e6; }
    .btn-delete { background-color: #e74c3c; }
    .text-center { text-align: center; }
</style>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    const chartData = @json($chartData);
    const chartLabels = @json($chartLabels);
    const datasets = [];

    const modernColors = [
        { border: 'rgba(54, 162, 235, 1)', background: 'rgba(54, 162, 235, 0.2)', point: 'rgba(54, 162, 235, 1)' },
        { border: 'rgba(255, 99, 132, 1)', background: 'rgba(255, 99, 132, 0.2)', point: 'rgba(255, 99, 132, 1)' },
        { border: 'rgba(75, 192, 192, 1)', background: 'rgba(75, 192, 192, 0.2)', point: 'rgba(75, 192, 192, 1)' },
        { border: 'rgba(255, 206, 86, 1)', background: 'rgba(255, 206, 86, 0.2)', point: 'rgba(255, 206, 86, 1)' },
        { border: 'rgba(153, 102, 255, 1)', background: 'rgba(153, 102, 255, 0.2)', point: 'rgba(153, 102, 255, 1)' },
        { border: 'rgba(255, 159, 64, 1)', background: 'rgba(255, 159, 64, 0.2)', point: 'rgba(255, 159, 64, 1)' }
    ];

    chartData.forEach((sales, index) => {
        const colorSet = modernColors[index % modernColors.length];
        datasets.push({
            label: sales.name,
            data: sales.data,
            borderColor: colorSet.border,
            backgroundColor: colorSet.background,
            pointBackgroundColor: colorSet.point,
            fill: true,
            tension: 0.3,
            borderWidth: 2,
            pointRadius: 3,
            pointHoverRadius: 6,
            pointBorderColor: '#fff',
            pointHoverBorderColor: colorSet.point,
            pointHoverBorderWidth: 2
        });
    });

    const salesInputCtx = document.getElementById('salesInputChart');
    if (salesInputCtx) {
        if (window.mySalesInputChart instanceof Chart) {
            window.mySalesInputChart.destroy();
        }
        window.mySalesInputChart = new Chart(salesInputCtx, {
            type: 'line',
            data: {
                labels: chartLabels,
                datasets: datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Jumlah Input',
                            font: { size: 14, weight: '500'},
                            color: document.body.classList.contains('dark') ? '#CFD8DC' : '#455A64'
                        },
                        grid: {
                            color: document.body.classList.contains('dark') ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)',
                            drawBorder: false,
                        },
                        ticks: {
                            color: document.body.classList.contains('dark') ? '#B0BEC5' : '#546E7A',
                            font: { size: 11 },
                            precision: 0
                        }
                    },
                    x: {
                         title: {
                            display: true,
                            text: 'Bulan dalam Setahun',
                            font: { size: 14, weight: '500'},
                            color: document.body.classList.contains('dark') ? '#CFD8DC' : '#455A64'
                        },
                        grid: {
                            display: false
                        },
                        ticks: {
                           color: document.body.classList.contains('dark') ? '#B0BEC5' : '#546E7A',
                           font: { size: 11 }
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: document.body.classList.contains('dark') ? '#ECEFF1' : '#37474F',
                            font: { size: 12 },
                            usePointStyle: true,
                            pointStyle: 'circle',
                            boxWidth: 8,
                            padding: 15
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: document.body.classList.contains('dark') ? 'rgba(40, 40, 40, 0.9)' :'rgba(255, 255, 255, 0.95)',
                        titleColor: document.body.classList.contains('dark') ? '#ECEFF1' : '#263238',
                        bodyColor: document.body.classList.contains('dark') ? '#CFD8DC' : '#37474F',
                        borderColor: document.body.classList.contains('dark') ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.1)',
                        borderWidth: 1,
                        titleFont: { size: 13, weight: 'bold' },
                        bodyFont: { size: 12 },
                        padding: 12,
                        cornerRadius: 5,
                        displayColors: true,
                        boxPadding: 4
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                },
                animation: {
                    duration: 800,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
});
</script>
@endsection