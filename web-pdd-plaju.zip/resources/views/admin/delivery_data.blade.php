@extends('layouts.app')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Data Pengiriman</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Data Pengiriman</a></li>
        </ul>
    </div>
</div>

<ul class="box-info">
    <li>
        <i class='bx bxs-calendar'></i>
        <span class="text">
            <h3>{{ $stats['total'] }}</h3>
            <p>Total Pengiriman</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-time-five'></i>
        <span class="text">
            <h3>{{ $stats['pending'] }}</h3>
            <p>Pending</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-truck'></i>
        <span class="text">
            <h3>{{ $stats['process'] }}</h3>
            <p>Dalam Proses</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-check-circle'></i>
        <span class="text">
            <h3>{{ $stats['completed'] }}</h3>
            <p>Selesai</p>
        </span>
    </li>
</ul>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Daftar Seluruh Pengiriman</h3>
            <div class="search-container">
                <form action="{{ route('admin.delivery_data') }}" method="GET">
                    <input type="text" name="search" placeholder="Cari (No SPK, Pemesan, Mobil...)" value="{{ request('search') }}">
                    <button type="submit"><i class='bx bx-search'></i></button>
                </form>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Nama Pemesan</th>
                    <th>Type Mobil</th>
                    <th>Sales</th>
                    <th>Jadwal Delivery</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($deliveryRequests as $delivery)
                <tr>
                    <td>{{ $delivery->no_spk }}</td>
                    <td>{{ $delivery->nama_pemesan }}</td>
                    <td>{{ $delivery->type_mobil }}</td>
                    <td>{{ $delivery->user->username }}</td>
                    <td>{{ $delivery->tanggal_delivery->format('d/m/Y') }}</td>
                    <td>
                        @if($delivery->status == 'completed')
                            <span class="status {{ $delivery->is_rescheduled ? 'terlambat' : 'completed' }}">Selesai</span>
                        @else
                            <span class="status {{ $delivery->status }}">{{ ucfirst($delivery->status) }}</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('admin.show_delivery', $delivery->id) }}" class="btn-view">Detail</a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align: center;">Tidak ada data pengiriman.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
        
     <div class="pagination">
        {{ $deliveryRequests->appends(request()->query())->links() }}
    </div>
    </div>
</div>
@endsection

@section('css')
<style>
    .btn-view { background-color: #3c91e6; color: white; padding: 5px 10px; border-radius: 5px; text-decoration: none; }
    .search-container { display: flex; margin-left: auto; }
    .search-container form { display: flex; }
    .search-container input { width: 200px; padding: 8px 10px; border: 1px solid #ddd; border-radius: 20px 0 0 20px; outline: none; }
    .search-container button { padding: 0 10px; border: none; background: var(--red); color: white; border-radius: 0 20px 20px 0; cursor: pointer; }
</style>
@endsection