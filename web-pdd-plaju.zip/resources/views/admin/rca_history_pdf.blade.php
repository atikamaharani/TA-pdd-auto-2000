<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>{{ $title }}</title>
    <style>
        body { 
            font-family: 'Helvetica', sans-serif;
            font-size: 10px; 
            line-height: 1.4;
        }
        .header { 
            text-align: center;
            margin-bottom: 25px; 
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .header h2 {
            margin-bottom: 5px;
        }
        .header p {
            margin: 0;
            font-size: 12px;
        }
        table { 
            width: 100%;
            border-collapse: collapse; 
        }
        th, td { 
            border: 1px solid #ccc;
            padding: 6px; 
            text-align: left; 
            vertical-align: top;
            word-wrap: break-word;
        }
        th { 
            background-color: #f2f2f2;
            font-weight: bold; 
        }
        .footer {
            margin-top: 20px;
            font-size: 9px;
            color: #555;
        }
        .status-completed-late {
            color: #c0392b;
            font-weight: bold;
        }
        .status-terlambat {
            color: #e74c3c;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>{{ $title }}</h2>
        <p>Periode: {{ $period }}</p>
        <p>Dicetak pada: {{ date('d F Y') }}</p>
    </div>
    <table>
        <thead>
            <tr>
                <th style="width: 5%;">No.</th>
                <th style="width: 12%;">No SPK</th>
                <th style="width: 15%;">Pemesan</th>
                <th style="width: 12%;">Sales</th>
                <th style="width: 15%;">Kategori RCA</th>
                <th style="width: 21%;">Penyebab Spesifik</th>
                <th style="width: 20%;">Status Saat Ini</th>
            </tr>
        </thead>
        <tbody>
            @forelse($history as $index => $item)
            <tr>
                <td style="text-align: center;">{{ $index + 1 }}</td>
                <td>
                    {{ $item->no_spk }}<br>
                    <small>Tgl Aktual: {{ $item->actual_delivery_date ? \Carbon\Carbon::parse($item->actual_delivery_date)->format('d/m/Y') : 'N/A' }}</small>
                </td>
                <td>{{ $item->nama_pemesan }}</td>
                <td>{{ $item->user->username }}</td>
                <td>{{ $item->rca_category ?? 'N/A' }}</td>
                <td>{{ $item->rca_specific_cause ?? 'N/A' }}</td>
                <td>
                    @if($item->status == 'completed')
                        <span class="status-completed-late">Selesai*</span>
                    @else
                        <span class="status-terlambat">{{ ucfirst($item->status) }}</span>
                    @endif
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7" style="text-align: center; padding: 20px;">Tidak ada data histori keterlambatan untuk periode ini.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
    <div class="footer">
        @if($history->where('is_rescheduled', true)->where('status', 'completed')->count() > 0)
            <p>* Menandakan pengiriman selesai namun pernah dijadwalkan ulang (reschedule).</p>
        @endif
    </div>
</body>
</html>