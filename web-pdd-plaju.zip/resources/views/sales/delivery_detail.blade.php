@extends('layouts.app')

@section('title', 'Detail Pengiriman Sales')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Detail Pengiriman #{{ $delivery->id }}</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('sales.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="{{ route('sales.deliveries') }}">Daftar Pengiriman</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Detail</a></li>
        </ul>
    </div>
    <a href="{{ route('sales.deliveries') }}" class="btn-download" style="background-color: var(--blue) !important;">
        <i class='bx bx-arrow-back'></i>
        <span class="text">Kembali</span>
    </a>
</div>

<div class="table-data">
    <div class="order detail-card">
        <div class="head">
            <h3>Informasi Pengiriman</h3>
            <div class="status-badge 
                @if($delivery->status == 'completed' && $delivery->is_rescheduled)
                    terlambat
                @else
                    {{ $delivery->status }}
                @endif">
                {{ $delivery->status == 'completed' ? 'Selesai' : ucfirst($delivery->status) }}
            </div>
        </div>
        
        <div class="info-section">
            <div class="info-column">
                <div class="info-group">
                    <h4>Informasi Customer</h4>
                    <div class="info-row">
                        <span class="label">Nama Pemesan:</span>
                        <span class="value">{{ $delivery->nama_pemesan }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">No. HP:</span>
                        <span class="value">{{ $delivery->no_hp }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Salesforce:</span>
                        <span class="value">{{ $delivery->salesforce }}</span>
                    </div>
                     <div class="info-row">
                        <span class="label">Diajukan Oleh:</span>
                        <span class="value">{{ $delivery->user->username }}</span>
                    </div>
                </div>
                
                <div class="info-group">
                    <h4>Informasi Pengiriman</h4>
                    <div class="info-row">
                        <span class="label">Tanggal Delivery:</span>
                        <span class="value">{{ $delivery->tanggal_delivery->format('d/m/Y') }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Jam Delivery:</span>
                        <span class="value">{{ $delivery->jam_delivery }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Lokasi Delivery:</span>
                        <span class="value">{{ $delivery->lokasi_delivery }}</span>
                    </div>
                </div>
            </div>
            
            <div class="info-column">
                <div class="info-group">
                    <h4>Informasi Kendaraan</h4>
                    <div class="info-row">
                        <span class="label">No. SPK:</span>
                        <span class="value">{{ $delivery->no_spk }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Type Mobil:</span>
                        <span class="value">{{ $delivery->type_mobil }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Warna:</span>
                        <span class="value">{{ $delivery->warna }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Posisi Unit:</span>
                        <span class="value">{{ $delivery->posisi_unit }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">No. Rangka:</span>
                        <span class="value">{{ $delivery->no_rangka }}</span>
                    </div>
                </div>
                
                <div class="info-group">
                    <h4>Informasi Pembayaran</h4>
                    <div class="info-row">
                        <span class="label">Cara Bayar:</span>
                        <span class="value">{{ $delivery->cara_bayar }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Leasing:</span>
                        <span class="value">{{ $delivery->leasing ?? '-' }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Status Transaksi:</span>
                        <span class="value">{{ $delivery->status_transaksi }}</span>
                    </div>
                </div>
            </div>
        </div>
        
        @if($delivery->catatan)
        <div class="note-section">
            <h4>Catatan Sales</h4>
            <p>{{ $delivery->catatan }}</p>
        </div>
        @endif

        @if($delivery->gudang_notes)
        <div class="note-section gudang-notes">
            <h4>Catatan Gudang</h4>
            <p>{{ $delivery->gudang_notes }}</p>
        </div>
        @endif

        @if($delivery->is_rescheduled && ($delivery->rca_category || $delivery->rca_specific_cause || $delivery->rca_improvement))
        <div class="note-section rca-notes">
            <h4>Root Cause Analysis (RCA) - Laporan Keterlambatan</h4>
            <div class="rca-content">
                @if($delivery->rca_category)
                <p><strong>Kategori Fishbone (6M):</strong> {{ $delivery->rca_category }}</p>
                @endif
                @if($delivery->rca_specific_cause)
                <p><strong>Penyebab Spesifik:</strong> {{ $delivery->rca_specific_cause }}</p>
                @endif
                @if($delivery->rca_improvement)
                <p><strong>Usulan Perbaikan:</strong> {{ $delivery->rca_improvement }}</p>
                @endif
            </div>
        </div>
        @endif

        @if($delivery->actual_delivery_date)
        <div class="actual-delivery-section">
            <h4>Informasi Pengiriman Aktual</h4>
            <div class="info-row">
                <span class="label">Tanggal Pengiriman Aktual:</span>
                <span class="value">{{ $delivery->actual_delivery_date->format('d/m/Y') }}</span>
            </div>
            @if($delivery->actual_delivery_time)
            <div class="info-row">
                <span class="label">Jam Pengiriman Aktual:</span>
                <span class="value">{{ $delivery->actual_delivery_time }}</span>
            </div>
            @endif
        </div>
        @endif

        <div class="timeline-section">
            <h4>Status Timeline</h4>
            <div class="timeline">
                <div class="timeline-item status-created active">
                    <div class="timeline-badge">
                        <i class='bx bx-plus-circle'></i>
                    </div>
                    <div class="timeline-content">
                        <h5>Permintaan Dibuat</h5>
                        <p>{{ $delivery->created_at->format('d/m/Y H:i') }} oleh {{ $delivery->user->username }}</p>
                    </div>
                </div>
                
                <div class="timeline-item {{ $delivery->status == 'process' || $delivery->status == 'completed' || $delivery->status == 'terlambat' ? 'status-process active' : '' }}">
                    <div class="timeline-badge">
                        <i class='bx bx-package'></i>
                    </div>
                    <div class="timeline-content">
                        <h5>Diproses Gudang</h5>
                        <p>{{ ($delivery->status != 'pending') ? $delivery->updated_at->format('d/m/Y H:i') : 'Menunggu update dari gudang' }}</p>
                        @if(($delivery->status != 'pending') && $delivery->gudang_notes)
                            <small>Catatan Gudang: {{ $delivery->gudang_notes }}</small>
                        @endif
                    </div>
                </div>
            
                <div class="timeline-item {{ $delivery->status == 'completed' || $delivery->status == 'terlambat' ? ($delivery->is_rescheduled ? 'status-late-completed active' : 'status-completed active') : '' }}">
                    <div class="timeline-badge">
                        <i class='bx {{ $delivery->is_rescheduled || $delivery->status == 'terlambat' ? 'bx-error-circle' : 'bx-check-circle' }}'></i>
                    </div>
                    <div class="timeline-content">
                        <h5>
                            @if($delivery->status == 'completed' && $delivery->is_rescheduled)
                                Selesai (Reschedule)
                            @elseif($delivery->status == 'completed')
                                Selesai
                            @elseif($delivery->status == 'terlambat')
                                Pengiriman Terlambat
                            @else
                                Belum Selesai
                            @endif
                        </h5>
                        <p>{{ ($delivery->status == 'completed' || $delivery->status == 'terlambat') ? ($delivery->actual_delivery_date ? $delivery->actual_delivery_date->format('d/m/Y') . ' ' . ($delivery->actual_delivery_time ?? '') : $delivery->updated_at->format('d/m/Y H:i')) : 'Menunggu konfirmasi dari gudang' }}</p>
                        @if($delivery->is_rescheduled && $delivery->rca_category)
                            <small>Kategori Penyebab: {{ $delivery->rca_category }}</small>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('css')
<style>
    .detail-card { padding: 20px; }
    .info-section { display: flex; flex-wrap: wrap; gap: 30px; margin-top: 20px; margin-bottom: 20px; }
    .info-column { flex: 1; min-width: 300px; }
    .info-group { margin-bottom: 20px; }
    .info-group h4 { margin-bottom: 10px; padding-bottom: 5px; border-bottom: 1px solid #ddd; }
    .info-row { display: flex; margin-bottom: 8px; }
    .info-row .label { flex: 0 0 150px; font-weight: 500; }
    .info-row .value { flex: 1; }
    .note-section, .actual-delivery-section { margin: 20px 0; padding: 15px; background-color: #f9f9f9; border-radius: 5px; }
    .note-section h4, .actual-delivery-section h4 { margin-bottom: 10px; }
    .gudang-notes { background-color: #e9f7fe; border-left: 4px solid #3498db; }
    .rca-notes { background-color: #fff3cd; border-left: 4px solid #ffc107; }
    .rca-content p { margin-bottom: 8px; }
    .timeline-section { margin-top: 30px; }
    .timeline-section h4 { margin-bottom: 15px; padding-bottom: 5px; border-bottom: 1px solid #ddd; }
    .timeline { position: relative; padding: 20px 0; }
    .timeline:before { content: ''; position: absolute; top: 0; bottom: 0; width: 2px; background: #ddd; left: 20px; margin-left: -1px; }
    .timeline-item { position: relative; margin-bottom: 25px; padding-left: 60px; }
    .timeline-badge { width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; position: absolute; top: 0; left: 0; }
    .timeline-badge i { font-size: 20px; }
    .timeline-content { background: white; padding: 15px; border-radius: 5px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); position: relative; }
    .timeline-content h5 { margin: 0 0 5px; font-weight: 500; }
    .timeline-content p { margin: 0; color: #777; font-size: 13px; }
    .timeline-content small { font-size: 0.85em; color: #555; display: block; margin-top: 5px; }
    .status-badge { padding: 5px 15px; border-radius: 20px; font-size: 14px; font-weight: 500; }
    .status-badge.pending { background-color: #ff6b6b; color: white; }
    .status-badge.process { background-color: #ffce26; color: black; }
    .status-badge.completed { background-color: #4cd137; color: white; }
    .status-badge.terlambat { background-color: #e74c3c; color: white; }
    .timeline-item.status-created .timeline-badge { background-color: #3498db; color: white; }
    .timeline-item.status-process .timeline-badge { background-color: #ffce26; color: black; }
    .timeline-item.status-completed .timeline-badge { background-color: #4cd137; color: white; }
    .timeline-item.status-late-completed .timeline-badge { background-color: #e74c3c; color: white; }
    .timeline-item:not(.active) .timeline-badge { background-color: #e0e0e0; color: #777; }
</style>
@endsection