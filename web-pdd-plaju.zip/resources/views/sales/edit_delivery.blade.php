@extends('layouts.app')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Edit Delivery Request #{{ $deliveryRequest->id }}</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('sales.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a href="{{ route('sales.deliveries') }}">Permintaan Pengiriman</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Edit Delivery Request</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Form Edit Delivery Request</h3>
        </div>
        
        <form action="{{ route('sales.update_delivery', $deliveryRequest->id) }}" method="POST" class="delivery-form">
            @csrf
            @method('PUT')
            <div class="form-row">
                <div class="form-group">
                    <label for="salesforce">Salesforce / SPV</label>
                    <input type="text" id="salesforce" name="salesforce" required value="{{ old('salesforce', $deliveryRequest->salesforce) }}">
                </div>
                
                <div class="form-group">
                    <label for="nama_pemesan">Nama Pemesan</label>
                    <input type="text" id="nama_pemesan" name="nama_pemesan" required value="{{ old('nama_pemesan', $deliveryRequest->nama_pemesan) }}">
                </div>
                
                <div class="form-group">
                    <label for="no_hp">No HP</label>
                    <input type="text" id="no_hp" name="no_hp" required value="{{ old('no_hp', $deliveryRequest->no_hp) }}">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="no_spk">No SPK</label>
                    <input type="text" id="no_spk" name="no_spk" required value="{{ old('no_spk', $deliveryRequest->no_spk) }}">
                </div>
                
                <div class="form-group">
                    <label for="type_mobil">Type Mobil</label>
                    <input type="text" id="type_mobil" name="type_mobil" required value="{{ old('type_mobil', $deliveryRequest->type_mobil) }}">
                </div>
                
                <div class="form-group">
                    <label for="warna">Warna</label>
                    <input type="text" id="warna" name="warna" required value="{{ old('warna', $deliveryRequest->warna) }}">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="posisi_unit">Posisi Unit</label>
                    <input type="text" id="posisi_unit" name="posisi_unit" required value="{{ old('posisi_unit', $deliveryRequest->posisi_unit) }}">
                </div>
                
                <div class="form-group">
                    <label for="no_rangka">No Rangka</label>
                    <input type="text" id="no_rangka" name="no_rangka" required value="{{ old('no_rangka', $deliveryRequest->no_rangka) }}">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="cara_bayar">Cara Bayar</label>
                    <select id="cara_bayar" name="cara_bayar" required>
                        <option value="">Pilih Metode</option>
                        <option value="Tunai" {{ old('cara_bayar', $deliveryRequest->cara_bayar) == 'Tunai' ? 'selected' : '' }}>Tunai</option>
                        <option value="Kredit" {{ old('cara_bayar', $deliveryRequest->cara_bayar) == 'Kredit' ? 'selected' : '' }}>Kredit</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="leasing">Leasing</label>
                    <input type="text" id="leasing" name="leasing" value="{{ old('leasing', $deliveryRequest->leasing) }}">
                </div>
                
                <div class="form-group">
                    <label for="status_transaksi">Status Transaksi</label>
                    <input type="text" id="status_transaksi" name="status_transaksi" required value="{{ old('status_transaksi', $deliveryRequest->status_transaksi) }}">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="tanggal_delivery">Tanggal Delivery</label>
                    <input type="date" id="tanggal_delivery" name="tanggal_delivery" required value="{{ old('tanggal_delivery', $deliveryRequest->tanggal_delivery->format('Y-m-d')) }}">
                </div>
                
                <div class="form-group">
                    <label for="jam_delivery">Jam Delivery</label>
                    <input type="time" id="jam_delivery" name="jam_delivery" required value="{{ old('jam_delivery', $deliveryRequest->jam_delivery) }}">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="lokasi_delivery">Lokasi Delivery</label>
                    <input type="text" id="lokasi_delivery" name="lokasi_delivery" required value="{{ old('lokasi_delivery', $deliveryRequest->lokasi_delivery) }}">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="catatan">Catatan</label>
                    <textarea id="catatan" name="catatan" rows="3">{{ old('catatan', $deliveryRequest->catatan) }}</textarea>
                </div>
            </div>
            
            <div class="form-row">
                <button type="submit" class="btn-submit">Update Request</button>
                 <a href="{{ route('sales.deliveries') }}" class="btn-cancel" style="padding: 10px 20px; background-color: #7f8c8d; color: white; text-decoration: none; border-radius: 4px; font-size: 14px; text-align:center;">Batal</a>
            </div>
        </form>
    </div>
</div>
@endsection

@section('css')
<style>
    .delivery-form {
        width: 100%;
    }
    .form-row {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 15px;
        gap: 15px;
    }
    .form-group {
        flex: 1;
        min-width: 250px;
    }
    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
    }
    .form-group input, .form-group select, .form-group textarea {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
    }
    .btn-submit {
        background-color: #d71920;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s;
        font-size: 14px;
    }
    .btn-submit:hover {
        background-color: #b5141a;
    }
</style>
@endsection