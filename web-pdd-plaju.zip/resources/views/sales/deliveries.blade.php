@extends('layouts.app')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Permintaan Pengiriman Saya</h1>
        <ul class="breadcrumb">
            <li><a href="{{ route('sales.dashboard') }}">Dashboard</a></li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Permintaan Pengiriman</a></li>
        </ul>
    </div>
    <a href="{{ route('sales.input_form') }}" class="btn-download">
        <i class='bx bxs-plus-circle'></i>
        <span class="text">Buat Permintaan Baru</span>
    </a>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Daftar Permintaan Saya</h3>
            <div class="search-container">
                <form action="{{ route('sales.deliveries') }}" method="GET">
                    <input type="text" name="search" placeholder="Cari (No SPK, Pemesan, Mobil...)" value="{{ request('search') }}">
                    <button type="submit"><i class='bx bx-search'></i></button>
                </form>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>No SPK</th>
                    <th>Nama Pemesan</th>
                    <th>Type Mobil</th>
                    <th>Jadwal Delivery</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($deliveryRequests as $delivery)
                <tr>
                    <td>{{ $delivery->no_spk }}</td>
                    <td>{{ $delivery->nama_pemesan }}</td>
                    <td>{{ $delivery->type_mobil }}</td>
                    <td>{{ $delivery->tanggal_delivery->format('d/m/Y') }} {{ $delivery->jam_delivery }}</td>
                    <td>
                        @if($delivery->status == 'completed')
                            <span class="status {{ $delivery->is_rescheduled ? 'terlambat' : 'completed' }}">Selesai</span>
                        @else
                            <span class="status {{ $delivery->status }}">{{ ucfirst($delivery->status) }}</span>
                        @endif
                    </td>
                    <td class="action-buttons">
                        <a href="{{ route('sales.show_delivery', $delivery->id) }}" class="btn-action btn-view">Detail</a>
                        @if($delivery->status == 'pending')
                        <a href="{{ route('sales.edit_delivery', $delivery->id) }}" class="btn-action btn-edit">Edit</a>
                        <form action="{{ route('sales.destroy_delivery', $delivery->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus permintaan ini?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-action btn-delete">Hapus</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align: center;">Anda belum membuat permintaan pengiriman.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
        
        <div class="pagination">
            {{ $deliveryRequests->appends(request()->query())->links() }}
        </div>
    </div>
</div>
@endsection

@section('css')
<style>
    .action-buttons { display: flex; align-items: center; gap: 5px; }
    .btn-action { text-decoration: none; font-size: 12px; padding: 4px 8px; border-radius: 3px; }
    .btn-view { background-color: #3498db; color: white; }
    .btn-edit { background-color: #f1c40f; color: black; }
    .btn-delete { background-color: #e74c3c; color: white; border: none; cursor: pointer; font-family: inherit; }
    .search-container { display: flex; margin-left: auto; }
    .search-container form { display: flex; }
    .search-container input { width: 200px; padding: 8px 10px; border: 1px solid #ddd; border-radius: 20px 0 0 20px; outline: none; }
    .search-container button { padding: 0 10px; border: none; background: var(--red); color: white; border-radius: 0 20px 20px 0; cursor: pointer; }
</style>
@endsection