@extends('layouts.app')

@section('title', 'Profile')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Profile Saya</h1>
        <ul class="breadcrumb">
            <li>
                @if(Auth::user()->role == 'admin')
                    <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                @elseif(Auth::user()->role == 'sales')
                    <a href="{{ route('sales.dashboard') }}">Dashboard</a>
                @elseif(Auth::user()->role == 'gudang')
                    <a href="{{ route('gudang.dashboard') }}">Dashboard</a>
                @endif
            </li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Profile</a></li>
        </ul>
    </div>
    <a href="{{ route('profile.edit') }}" class="btn-download">
        <i class='bx bx-edit'></i>
        <span class="text">Edit Profile</span>
    </a>
</div>

<div class="table-data">
    <div class="order profile-card">
        <div class="head">
            <h3>Informasi Profile</h3>
        </div>

        <div class="profile-content">
            <div class="avatar-section">
                <div class="avatar-container">
                <img src="{{ $user->avatar ? asset('storage/' . $user->avatar) : asset('images/default-avatar.png') }}" alt="Avatar" class="avatar-img">
                </div>
                <div class="avatar-info">
                    <h4>{{ $user->username }}</h4>
                    <span class="role-badge {{ strtolower($user->role) }}">{{ ucfirst($user->role) }}</span>
                </div>
            </div>

            <div class="info-section">
                <div class="info-group">
                    <h4>Informasi Akun</h4>
                    <div class="info-row">
                        <span class="label">Username:</span>
                        <span class="value">{{ $user->username }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Email:</span>
                        <span class="value">{{ $user->email }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Role:</span>
                        <span class="value">{{ ucfirst($user->role) }}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Status:</span>
                        <span class="value">
                            @if($user->is_active)
                                <span class="status active">Aktif</span>
                            @else
                                <span class="status inactive">Tidak Aktif</span>
                            @endif
                        </span>
                    </div>
                    <div class="info-row">
                        <span class="label">Bergabung:</span>
                        <span class="value">{{ $user->created_at->format('d/m/Y H:i') }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('css')
<style>
    .profile-card { padding: 20px; }
    .profile-content { margin-top: 20px; }
    .avatar-section { display: flex; align-items: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #ddd; }
    .avatar-container { margin-right: 20px; }
    .avatar-img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #ddd; }
    .avatar-info h4 { margin: 0 0 5px; font-size: 24px; }
    .role-badge { padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; text-transform: uppercase; }
    .role-badge.admin { background-color: #e74c3c; color: white; }
    .role-badge.sales { background-color: #3498db; color: white; }
    .role-badge.gudang { background-color: #f39c12; color: white; }
    .info-section { display: flex; flex-wrap: wrap; gap: 30px; }
    .info-group { flex: 1; min-width: 300px; }
    .info-group h4 { margin-bottom: 15px; padding-bottom: 5px; border-bottom: 1px solid #ddd; }
    .info-row { display: flex; margin-bottom: 10px; }
    .info-row .label { flex: 0 0 120px; font-weight: 500; }
    .info-row .value { flex: 1; }
    .status { padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; }
    .status.active { background-color: #d4edda; color: #155724; }
    .status.inactive { background-color: #f8d7da; color: #721c24; }
</style>
@endsection
