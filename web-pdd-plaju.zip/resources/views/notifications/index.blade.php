@extends('layouts.app')

@section('title', 'Notifikasi')

@section('content')
<div class="head-title">
    <div class="left">
        <h1>Notifikasi</h1>
        <ul class="breadcrumb">
            <li>
                @if(Auth::user()->role == 'admin')
                    <a href="{{ route('dashboard.admin') }}">Dashboard</a>
                @elseif(Auth::user()->role == 'sales')
                    <a href="{{ route('sales.dashboard') }}">Dashboard</a>
                @elseif(Auth::user()->role == 'gudang')
                    <a href="{{ route('gudang.dashboard') }}">Dashboard</a>
                @endif
            </li>
            <li><i class='bx bx-chevron-right'></i></li>
            <li><a class="active" href="#">Notifikasi</a></li>
        </ul>
    </div>
</div>

<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Semua Notifikasi</h3>
            <form action="{{ route('notifications.mark_all_read') }}" method="POST" style="margin-left: auto;">
                @csrf
                <button type="submit" class="btn-mark-all">
                    <i class='bx bx-check-double'></i>
                    Tandai Semua Dibaca
                </button>
            </form>
        </div>
        
        <div class="notification-list">
            @if(count($notifications) > 0)
                @foreach($notifications as $notification)
                <div class="notification-item {{ $notification->is_read ? 'read' : 'unread' }} {{ strpos(strtolower($notification->content), 'pending') !== false ? 'pending-notif' : (strpos(strtolower($notification->content), 'proses') !== false || strpos(strtolower($notification->content), 'process') !== false ? 'process-notif' : (strpos(strtolower($notification->content), 'selesai') !== false || strpos(strtolower($notification->content), 'completed') !== false ? 'completed-notif' : '')) }}">
                    <div class="notification-icon">
                        <i class='bx bxs-bell'></i>
                    </div>
                    <div class="notification-content">
                        <p>{{ $notification->content }}</p>
                        <small>{{ $notification->created_at->diffForHumans() }}</small>
                    </div>
                    @if(!$notification->is_read)
                    <div class="notification-action">
                        <a href="{{ route('notifications.mark_read', $notification->id) }}" class="mark-read">
                            <i class='bx bx-check'></i> Tandai Sudah Dibaca
                        </a>
                    </div>
                    @endif
                </div>
                @endforeach
                
                <div class="pagination">
                    {{ $notifications->links() }}
                </div>
            @else
                <div class="notification-empty">
                    <i class='bx bx-bell-off'></i>
                    <p>Belum ada notifikasi</p>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection

@section('css')
<style>
    .btn-mark-all {
        background-color: var(--blue);
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        font-size: 14px;
    }
    .notification-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    
    .notification-item {
        display: flex;
        align-items: flex-start;
        padding: 15px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        background-color: #f9f9f9;
    }
    
    .notification-item.unread {
        background-color: #fff;
    }
    
    .notification-item.read {
        opacity: 0.8;
    }
    
    .notification-item.pending-notif {
        border-left: 3px solid #ff6b6b;
    }
    
    .notification-item.process-notif {
        border-left: 3px solid #ffce26;
    }
    
    .notification-item.completed-notif {
        border-left: 3px solid #4cd137;
    }
     .notification-item.unread:not(.pending-notif):not(.process-notif):not(.completed-notif) {
        border-left: 3px solid #d71920;
    }
    
    .notification-icon {
        flex: 0 0 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #d71920;
        font-size: 24px;
    }
    
    .notification-content {
        flex: 1;
        margin: 0 15px;
    }
    
    .notification-content p {
        margin: 0 0 5px;
    }
    
    .notification-content small {
        color: #777;
    }
    
    .notification-action {
        align-self: flex-end;
    }
    
    .mark-read {
        display: inline-flex;
        align-items: center;
        padding: 5px 10px;
        background-color: #3c91e6;
        color: white;
        border-radius: 4px;
        font-size: 12px;
        text-decoration: none;
    }
    
    .mark-read i {
        margin-right: 5px;
    }
    
    .notification-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 50px 0;
        color: #aaa;
    }
    
    .notification-empty i {
        font-size: 40px;
        margin-bottom: 10px;
    }
</style>
@endsection