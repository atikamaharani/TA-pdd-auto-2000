@extends('layouts.app')

@section('content')
    @if(isset($isReminderNeeded) && $isReminderNeeded)
        <div class="alert alert-info">
            <i class='bx bx-info-circle'></i>
            <strong>Reminder:</strong> Anda belum membuat Delivery Request untuk pengiriman H+2 (Tanggal: {{ \Carbon\Carbon::parse($deliveryTargetDate)->format('d F Y') }}).
        </div>
    @endif

    <div class="head-title">
        <div class="left">
            <h1>Selamat Datang di Dashboard Sales</h1>
            <ul class="breadcrumb">
                <li><a href="{{ route('sales.dashboard') }}">Dashboard</a></li>
                <li><i class='bx bx-chevron-right'></i></li>
                <li><a class="active" href="#">Home</a></li>
            </ul>
        </div>
        <a href="{{ route('sales.input_form') }}" class="btn-download">
            <i class='bx bxs-plus-circle'></i>
            <span class="text">Input Delivery Request</span>
        </a>
    </div>

    <ul class="box-info">
        <li>
            <i class='bx bxs-edit'></i>
            <span class="text">
                <h3>{{ $statistics['total'] }}</h3>
                <p>Total Input</p>
            </span>
        </li>
        <li>
            <i class='bx bxs-time-five'></i>
            <span class="text">
                <h3>{{ $statistics['pending'] + $statistics['process'] }}</h3>
                <p>Dalam Proses</p>
            </span>
        </li>
        <li>
            <i class='bx bxs-check-circle'></i>
            <span class="text">
                <h3>{{ $statistics['completed'] }}</h3>
                <p>Selesai</p>
            </span>
        </li>
    </ul>

    <div class="table-data">
        <div class="order">
            <div class="head">
                <h3>Permintaan Pengiriman Saya</h3>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Pemesan</th>
                        <th>Type Mobil</th>
                        <th>Tanggal Delivery</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($myDeliveries as $delivery)
                    <tr>
                        <td>{{ $delivery->nama_pemesan }}</td>
                        <td>{{ $delivery->type_mobil }}</td>
                        <td>{{ $delivery->tanggal_delivery->format('d/m/Y') }} {{ $delivery->jam_delivery }}</td>
                        <td>
                            @if($delivery->status == 'completed')
                                <span class="status {{ $delivery->is_rescheduled ? 'terlambat' : 'completed' }}">Selesai</span>
                            @else
                                <span class="status {{ $delivery->status }}">{{ ucfirst($delivery->status) }}</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" style="text-align: center;">Tidak ada data pengiriman.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
            @if($totalMyDeliveries > 3)
                <a href="{{ route('sales.deliveries') }}" class="view-all-link" style="display: block; text-align: right; margin-top: 10px; color: var(--blue); text-decoration: none; font-weight: 500;">Lihat Semua Pengiriman Saya &rarr;</a>
            @endif
        </div>

        <div class="todo">
            <div class="head">
                <h3>Notifikasi</h3>
            </div>
            <ul class="todo-list">
                @forelse($notifications as $notification)
                <li class="{{ strpos(strtolower($notification->content), 'pending') !== false ? 'not-completed' : (strpos(strtolower($notification->content), 'proses') !== false || strpos(strtolower($notification->content), 'process') !== false ? 'process' : (strpos(strtolower($notification->content), 'selesai') !== false || strpos(strtolower($notification->content), 'completed') !== false ? 'completed' : ($notification->is_read ? 'completed' : 'not-completed'))) }}">
                    <p>{{ Str::limit($notification->content, 50) }}</p>
                    <i class='bx bx-check {{ $notification->is_read ? "" : "bx-circle" }}'></i>
                </li>
                @empty
                <li class="not-completed">
                    <p>Belum ada notifikasi baru</p>
                </li>
                @endforelse
            </ul>
            @if($totalNotifications > 3)
                <a href="{{ route('notifications.index') }}" class="view-all-link" style="display: block; text-align: right; margin-top: 10px; color: var(--blue); text-decoration: none; font-weight: 500;">Lihat Semua Notifikasi &rarr;</a>
            @endif
        </div>
    </div>
@endsection
