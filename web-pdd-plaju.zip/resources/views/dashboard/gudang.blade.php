@extends('layouts.app')

@section('content')
<div class="head-title">
  <div class="left">
    <h1>Selamat Datang di Dashboard Gudang</h1>
     <ul class="breadcrumb">
      <li><a href="{{ route('gudang.dashboard') }}">Dashboard</a></li>
      <li><i class='bx bx-chevron-right'></i></li>
      <li><a class="active" href="#">Home</a></li>
    </ul>
  </div>
  <a href="{{ route('gudang.delivery_requests') }}" class="btn-download">
    <i class='bx bxs-car'></i>
     <span class="text">Lihat Semua Request</span>
  </a>
</div>

<ul class="box-info">
  <li>
    <i class='bx bxs-file-doc'></i>
    <span class="text">
      <h3>{{ $statistics['request'] }}</h3>
      <p>Total Request</p>
    </span>
  </li>
  <li>
    <i class='bx bxs-truck'></i>
    <span class="text">
      <h3>{{ $statistics['process'] }}</h3>
      <p>Sedang Diproses</p>
    </span>
  </li>
  <li>
    <i class='bx bxs-check-circle'></i>
    <span class="text">
      <h3>{{ $statistics['completed'] }}</h3>
      <p>Terkirim</p>
    </span>
  </li>
</ul>

<div class="table-data">
  <div class="order">
    <div class="head">
       <h3>Permintaan Pengiriman Terbaru</h3>
      <i class='bx bx-search'></i>
      <i class='bx bx-filter'></i>
    </div>
    <table>
      <thead>
        <tr>
          <th>No SPK</th>
          <th>Pemesan</th>
          <th>Type Mobil</th>
          <th>Sales</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
         @forelse($latestRequestsForGudang as $delivery)
        <tr>
          <td>{{ $delivery->no_spk }}</td>
          <td>{{ $delivery->nama_pemesan }}</td>
          <td>{{ $delivery->type_mobil }}</td>
          <td>{{ $delivery->user->username ?? 'N/A' }}</td>
          <td>
            @if($delivery->status == 'completed')
              <span class="status {{ $delivery->is_rescheduled ? 'terlambat' : 'completed' }}">Selesai</span>
            @else
              <span class="status {{ $delivery->status }}">{{ ucfirst($delivery->status) }}</span>
            @endif
          </td>
        </tr>
        @empty
        <tr>
          <td colspan="5" style="text-align: center;">Tidak ada permintaan pengiriman.</td>
        </tr>
         @endforelse
      </tbody>
    </table>
     @if($totalRequestsForGudang > 3)
      <a href="{{ route('gudang.delivery_requests') }}" class="view-all-link">Lihat Semua Permintaan &rarr;</a>
    @endif
  </div>
  
   <div class="todo">
     <div class="head">
      <h3>Notifikasi Terbaru</h3>
    </div>
    <ul class="todo-list">
      @forelse($notifications as $notification)
      <li class="{{ strpos(strtolower($notification->content), 'pending') !== false ? 'not-completed' : (strpos(strtolower($notification->content), 'proses') !== false || strpos(strtolower($notification->content), 'process') !== false ? 'process' : (strpos(strtolower($notification->content), 'selesai') !== false || strpos(strtolower($notification->content), 'completed') !== false ? 'completed' : ($notification->is_read ? 'completed' : 'not-completed'))) }}">
        <p>{{ Str::limit($notification->content, 50) }}</p>
        <i class='bx bx-check {{ $notification->is_read ? "" : "bx-circle" }}'></i>
      </li>
      @empty
       <li class="not-completed">
        <p>Belum ada notifikasi baru</p>
      </li>
      @endforelse
    </ul>
     @if($totalNotifications > 3)
      <a href="{{ route('notifications.index') }}" class="view-all-link">Lihat Semua Notifikasi &rarr;</a>
     @endif
  </div>
</div>
@endsection