<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>PDD Auto - @yield('title', 'Dashboard')</title>

  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="{{ asset('assets/css/dashboard.css') }}">
  <style>
    :root {
      --blue: #3c91e6;
      --red: #d71920;
    }
    .side-menu li.active a {
      color: var(--red);
    }
    .btn-download {
      background: var(--red);
    }
    .status {
      padding: 4px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 500;
    }
    .status.completed,
    .table-data .order table tr td .status.completed,
    table tr td .status.completed {
      background-color: #4cd137 !important;
      color: white !important;
    }
    .status.process,
    .table-data .order table tr td .status.process,
    table tr td .status.process {
      background-color: #ffce26 !important;
      color: black !important;
    }
    .status.pending,
    .table-data .order table tr td .status.pending,
    table tr td .status.pending {
      background-color: #ff6b6b !important;
      color: white !important;
    }
    .status.terlambat,
    .table-data .order table tr td .status.terlambat,
    table tr td .status.terlambat {
        background-color: #e74c3c !important;
        color: white !important;
    }
    .todo-list li.completed {
      border-left: 2px solid #4cd137 !important;
    }
    .todo-list li.not-completed {
      border-left: 2px solid #ff6b6b !important;
    }
    .todo-list li.process {
      border-left: 2px solid #ffce26 !important;
    }
    .notification-badge {
      position: absolute;
      top: 8px;
      right: 8px;
      background: #ff6b6b;
      color: white;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      font-size: 10px;
      text-align: center;
      line-height: 18px;
    }
    .alert {
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 5px;
    }
    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    .alert-error, .alert-danger {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    .alert-info {
        background-color: #d1ecf1;
        color: #0c5460;
        border: 1px solid #bee5eb;
    }
    .status-badge.pending {
      background-color: #ff6b6b !important;
      color: white !important;
    }
    .status-badge.process {
      background-color: #ffce26 !important;
      color: black !important;
    }
    .status-badge.completed {
      background-color: #4cd137 !important;
      color: white !important;
    }
    .status-badge.terlambat {
        background-color: #e74c3c !important;
        color: white !important;
    }
    .profile {
      display: flex;
      align-items: center;
      gap: 8px;
      text-decoration: none;
      color: inherit;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }
    .profile:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    .profile-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid #ddd;
      transition: border-color 0.3s;
    }
    .profile:hover .profile-avatar {
      border-color: var(--red);
    }
    .profile span {
      font-weight: 500;
    }
    #notification-popup-container {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .notification-popup {
        background-color: #fff;
        color: #333;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 15px;
        width: 350px;
        border-left: 5px solid var(--blue);
        transform: translateX(120%);
        animation: slideIn 0.5s forwards;
    }
    .notification-popup i {
        font-size: 24px;
        color: var(--blue);
    }
    .notification-popup p {
        margin: 0;
        font-size: 14px;
    }
    @keyframes slideIn {
        to {
            transform: translateX(0);
        }
    }
  </style>
  @yield('css')
</head>
<body>

<section id="sidebar">
    <a href="{{ auth()->user()->role == 'admin' ? route('admin.dashboard') : (auth()->user()->role == 'sales' ? route('sales.dashboard') : route('gudang.dashboard')) }}" class="brand">
    <img src="{{ asset('assets/img/logo-auto2000.png') }}" alt="Logo Auto2000" class="logo">
      <span class="text">PDD Auto2000 Plaju</span>
    </a>

    @if(auth()->user()->role == 'admin')
    <ul class="side-menu top">
      <li class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
        <a href="{{ route('admin.dashboard') }}">
          <i class='bx bxs-dashboard'></i>
          <span class="text">Dashboard</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('admin.sales_data') ? 'active' : '' }}">
        <a href="{{ route('admin.sales_data') }}">
          <i class='bx bxs-user-detail'></i>
          <span class="text">Data Sales & Karyawan</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('admin.delivery_data') ? 'active' : '' }}">
        <a href="{{ route('admin.delivery_data') }}">
          <i class='bx bxs-truck'></i>
          <span class="text">Data Pengiriman</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('admin.rca_dashboard') ? 'active' : '' }}">
        <a href="{{ route('admin.rca_dashboard') }}">
            <i class='bx bxs-error-alt'></i>
            <span class="text">RCA Dashboard</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('admin.notifications') ? 'active' : '' }}">
        <a href="{{ route('admin.notifications') }}">
          <i class='bx bxs-bell'></i>
          <span class="text">Notifikasi</span>
          <span class="notification-badge" id="notification-badge"></span>
        </a>
      </li>
      <li class="{{ request()->routeIs('admin.activity_log') ? 'active' : '' }}">
        <a href="{{ route('admin.activity_log') }}">
          <i class='bx bxs-time-five'></i>
          <span class="text">Log Aktivitas</span>
        </a>
      </li>
    </ul>
    @elseif(auth()->user()->role == 'sales')
    <ul class="side-menu top">
      <li class="{{ request()->routeIs('sales.dashboard') ? 'active' : '' }}">
        <a href="{{ route('sales.dashboard') }}">
          <i class='bx bxs-dashboard'></i>
          <span class="text">Dashboard</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('sales.input_form') ? 'active' : '' }}">
        <a href="{{ route('sales.input_form') }}">
          <i class='bx bxs-edit'></i>
          <span class="text">Input Delivery Request</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('sales.deliveries') ? 'active' : '' }}">
        <a href="{{ route('sales.deliveries') }}">
          <i class='bx bxs-car'></i>
          <span class="text">Daftar Pengiriman</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('sales.statistics') ? 'active' : '' }}">
        <a href="{{ route('sales.statistics') }}">
          <i class='bx bxs-bar-chart-alt-2'></i>
          <span class="text">Statistik Input</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('notifications.index') ? 'active' : '' }}">
        <a href="{{ route('notifications.index') }}">
          <i class='bx bxs-bell'></i>
          <span class="text">Notifikasi</span>
          <span class="notification-badge" id="notification-badge"></span>
        </a>
      </li>
    </ul>
    @else
    <ul class="side-menu top">
      <li class="{{ request()->routeIs('gudang.dashboard') ? 'active' : '' }}">
        <a href="{{ route('gudang.dashboard') }}">
          <i class='bx bxs-dashboard'></i>
          <span class="text">Dashboard</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('gudang.delivery_requests') ? 'active' : '' }}">
        <a href="{{ route('gudang.delivery_requests') }}">
          <i class='bx bxs-file-doc'></i>
          <span class="text">Delivery Requests</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('gudang.reports') ? 'active' : '' }}">
        <a href="{{ route('gudang.reports') }}">
          <i class='bx bxs-printer'></i>
          <span class="text">Cetak Laporan</span>
        </a>
      </li>
      <li class="{{ request()->routeIs('notifications.index') ? 'active' : '' }}">
        <a href="{{ route('notifications.index') }}">
          <i class='bx bxs-bell'></i>
          <span class="text">Notifikasi</span>
          <span class="notification-badge" id="notification-badge"></span>
        </a>
      </li>
    </ul>
    @endif

    <ul class="side-menu">
      <li class="{{ request()->routeIs('profile.*') ? 'active' : '' }}">
        <a href="{{ route('profile.show') }}">
          <i class='bx bx-user-circle'></i>
          <span class="text">Profile</span>
        </a>
      </li>
      <li>
        <a href="#" class="logout">
          <i class='bx bxs-log-out-circle'></i>
          <span class="text">Logout</span>
        </a>
        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
        </form>
      </li>
    </ul>
  </section>

  <section id="content">
    <nav>
      <i class='bx bx-menu'></i>
      <a href="#" class="nav-link">Menu</a>
      <form action="#">
      </form>
      <input type="checkbox" id="switch-mode" hidden>
      <label for="switch-mode" class="switch-mode"></label>
      <a href="{{ auth()->user()->role == 'admin' ? route('admin.notifications') : route('notifications.index') }}" class="notification">
        <i class='bx bxs-bell'></i>
        <span class="num" id="notification-count">0</span>
      </a>
      <a href="{{ route('profile.show') }}" class="profile">
        <img src="{{ Auth::user()->avatar_url }}" alt="Avatar" class="profile-avatar">
        <span>{{ Auth::user()->username }}</span>
      </a>
    </nav>

    <main>
      <div id="notification-popup-container"></div>
      @if(session('success'))
      <div class="alert alert-success">
           {{ session('success') }}
      </div>
      @endif

      @if(session('error'))
      <div class="alert alert-error">
        {{ session('error') }}
      </div>
      @endif

      @if($errors->any())
        <div class="alert alert-danger">
            <ul>
                 @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
      @endif

      @yield('content')
    </main>
  </section>

  <script src="{{ asset('assets/js/dashboard-admin.js') }}"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            setTimeout(function() {
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 500);
            }, 5000);
        });

        const logoutButton = document.querySelector('.logout');
        if (logoutButton) {
            logoutButton.addEventListener('click', function(e) {
                e.preventDefault();
                if (confirm('Apakah Anda yakin ingin logout?')) {
                    document.getElementById('logout-form').submit();
                }
            });
        }

        let lastNotificationId = 0;
        const notificationCountElement = document.getElementById('notification-count');
        const badgeElement = document.getElementById('notification-badge');
        const popupContainer = document.getElementById('notification-popup-container');

        function showNotificationPopup(notification) {
            const popup = document.createElement('div');
            popup.className = 'notification-popup';

            const icon = document.createElement('i');
            icon.className = 'bx bxs-info-circle';

            const text = document.createElement('p');
            text.textContent = notification.content.substring(0, 100) + (notification.content.length > 100 ? '...' : '');

            popup.appendChild(icon);
            popup.appendChild(text);

            popupContainer.appendChild(popup);

            setTimeout(() => {
                popup.style.animation = 'none';
                popup.style.opacity = '0';
                popup.style.transition = 'opacity 0.5s ease';
                setTimeout(() => popup.remove(), 500);
            }, 5000);
        }

        function updateNotifCount(count) {
             if (notificationCountElement) {
                notificationCountElement.textContent = count;
            }
            if (badgeElement) {
                if (count > 0) {
                    badgeElement.textContent = count;
                    badgeElement.style.display = 'inline-block';
                } else {
                    badgeElement.style.display = 'none';
                }
            }
        }

        function fetchLatestNotifications() {
            fetch(`{{ route("notifications.latest") }}?last_id=${lastNotificationId}`)
                .then(response => response.json())
                .then(notifications => {
                    if (notifications.length > 0) {
                        let currentUnreadCount = parseInt(notificationCountElement.textContent) || 0;
                        notifications.forEach(notif => {
                            showNotificationPopup(notif);
                            currentUnreadCount++;
                        });
                        lastNotificationId = notifications[notifications.length - 1].id;
                        updateNotifCount(currentUnreadCount);
                    }
                })
                .catch(error => console.error('Error fetching latest notifications:', error));
        }

        function loadInitialData() {
            try {
                fetch('{{ route("notifications.initial_data") }}')
                    .then(response => response.json())
                    .then(data => {
                        lastNotificationId = data.last_id || 0;
                        updateNotifCount(data.unread_count || 0);
                    })
                    .catch(error => console.error('Error fetching initial data:', error));
            } catch (error) {
                console.error('Error loading notifications:', error);
            }
        }

        loadInitialData();
        setInterval(fetchLatestNotifications, 3000);
    });
  </script>
  @yield('scripts')
</body>
</html>
