<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>PDD Auto</title>
  <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}" />
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
  <div class="auth-wrapper">
    <div class="image-container">
      <img src="{{ asset('assets/img/logo-auto2000.png') }}" alt="Car Sale Illustration">
    </div>

    <div id="auth-container">
      <div class="container">

        @if(session('success'))
        <div class="auth-alert-success">
            {{ session('success') }}
        </div>
        @endif

        @if(session('error'))
        <div class="error-message">
          {{ session('error') }}
        </div>
        @endif

        @if($errors->any())
        <div class="error-message">
          <ul>
            @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
        @endif

        <form id="login-form" class="active" method="POST" action="{{ url('/login') }}">
          @csrf
          <div class="title">Login</div>
          <div class="form-group">
            <label for="login-username">Username</label>
            <div class="input-group">
              <input type="text" id="login-username" name="username" placeholder="Username" required value="{{ old('username') }}" />
              <i class='bx bx-envelope'></i>
            </div>
          </div>
          <div class="form-group">
            <label for="login-password">Password</label>
            <div class="input-group">
              <input type="password" id="login-password" name="password" placeholder="Password" required />
              <i class='bx bx-lock-alt'></i>
            </div>
          </div>
          <button class="btn-submit" type="submit">Login</button>
          <!-- <div class="forgot-text"><a href="#" id="show-forgot">Lupa Password?</a></div> -->
        </form>
      </div>
    </div>
  </div>

  <script>
  setTimeout(() => {
    document.querySelectorAll('.auth-alert-success, .error-message').forEach(el => {
      el.classList.add('fade-out'); 
      el.classList.add('hidden');
      setTimeout(() => el.remove(), 400);
    });
  }, 2000);
</script>
  <script src="{{ asset('assets/js/script.js') }}"></script>
</body>
</html>
