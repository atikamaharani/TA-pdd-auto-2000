<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'from_user_id',
        'to_user_id',
        'to_role',
        'content',
        'related_id',
        'is_read',
    ];
    
    protected $casts = [
        'is_read' => 'boolean',
    ];
    
    public function fromUser()
    {
        return $this->belongsTo(User::class, 'from_user_id');
    }
    
    public function toUser()
    {
        return $this->belongsTo(User::class, 'to_user_id');
    }
    
    public function deliveryRequest()
    {
        return $this->belongsTo(DeliveryRequest::class, 'related_id');
    }
}