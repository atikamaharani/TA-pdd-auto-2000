<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'salesforce',
        'nama_pemesan',
        'no_hp',
        'no_spk',
        'type_mobil',
        'warna',
        'posisi_unit',
        'no_rangka',
        'cara_bayar',
        'leasing',
        'status_transaksi',
        'tanggal_delivery',
        'jam_delivery',
        'lokasi_delivery',
        'catatan',
        'status',
        'is_rescheduled',
        'gudang_notes',
        'actual_delivery_date',
        'actual_delivery_time',
        'rca_reason',
        'rca_category',
        'rca_specific_cause',
        'rca_improvement',
    ];

    protected $casts = [
        'tanggal_delivery' => 'date',
        'actual_delivery_date' => 'date',
        'is_rescheduled' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function getRcaCategories()
    {
        return [
            'Man' => [
                'Permintaan dari Customer',
                'Human Error (Kesalahan Input)',
                'Driver tidak tersedia',
                'Lainnya'
            ],
            'Method' => [
                'Kendala Administratif',
                'Jadwal Tidak Sinkron',
                'Koordinasi Logistik / Transit',
                'Lainnya'
            ],
            'Machine' => [
                'Kendala Teknis',
                'Masalah Aplikasi SAP / Delivery Order',
                'Lainnya'
            ],
            'Material' => [
                'Kendaraan Belum Tersedia',
                'Unit Belum Siap (Cuci, Aksesori)',
                'Lainnya'
            ],
            'Measurement' => [
                'Kendala Administratif / Data',
                'Ketidaksesuaian Data Unit / DO',
                'Lainnya'
            ],
            'Environment' => [
                'Cuaca',
                'Lainnya'
            ]
        ];
    }
}