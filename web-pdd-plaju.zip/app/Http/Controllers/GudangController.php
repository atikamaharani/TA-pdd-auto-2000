<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DeliveryRequest;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Barryvdh\DomPDF\Facade\Pdf;

class GudangController extends Controller
{
    public function index()
    {
        $pendingDeliveries = DeliveryRequest::where('status', 'pending')
            ->orderBy('tanggal_delivery', 'desc')
            ->limit(5)
            ->get();
        $todayDeliveries = DeliveryRequest::whereDate('tanggal_delivery', today())
            ->orderBy('jam_delivery', 'asc')
            ->get();
        $statistics = [
            'request' => DeliveryRequest::count(),
            'process' => DeliveryRequest::where('status', 'process')->count(),
            'completed' => DeliveryRequest::where('status', 'completed')->count(),
        ];
        return view('gudang.index', compact('pendingDeliveries', 'todayDeliveries', 'statistics'));
    }
    
    public function deliveryRequests(Request $request)
    {
        $query = DeliveryRequest::query();
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('no_spk', 'like', "%{$search}%")
                  ->orWhere('nama_pemesan', 'like', "%{$search}%")
                  ->orWhere('type_mobil', 'like', "%{$search}%")
                  ->orWhereHas('user', function ($userQuery) use ($search) {
                      $userQuery->where('username', 'like', "%{$search}%");
                  });
            });
        }
    
        $deliveryRequests = $query->orderBy('id', 'desc')->paginate(10);

        return view('gudang.delivery_requests', compact('deliveryRequests'));
    }
    
    public function showDeliveryRequest($id)
    {
        $deliveryRequest = DeliveryRequest::findOrFail($id);
        $rcaCategories = DeliveryRequest::getRcaCategories();
        
        $rcaCausesMap = [];
        $rcaSpecificCauses = [];

        foreach ($rcaCategories as $category => $causes) {
            foreach ($causes as $cause) {
                $rcaCausesMap[$cause] = $category;
                if (!in_array($cause, $rcaSpecificCauses)) {
                    $rcaSpecificCauses[] = $cause;
                }
            }
        }
        
        return view('gudang.show_delivery', compact('deliveryRequest', 'rcaCausesMap', 'rcaSpecificCauses'));
    }
    
    public function updateStatus(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:pending,process,completed,terlambat',
            'notes' => 'nullable|string',
            'actual_delivery_date' => 'nullable|date',
            'actual_delivery_time' => 'nullable',
            'rca_reason' => 'nullable|string|max:255',
            'rca_category' => 'required_if:status,terlambat|nullable|string',
            'rca_specific_cause' => 'nullable|string',
            'rca_improvement' => 'nullable|string',
        ], [
            'rca_category.required_if' => 'Kategori RCA wajib diisi untuk status terlambat',
        ]);

        if ($request->status === 'terlambat') {
            if (empty($request->rca_specific_cause)) {
                $validator->after(function ($validator) {
                    $validator->errors()->add('rca_specific_cause', 'Penyebab spesifik wajib diisi untuk status terlambat');
                });
            }
        }

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        
        $deliveryRequest = DeliveryRequest::findOrFail($id);
        $oldStatus = $deliveryRequest->status;
        
        $deliveryRequest->status = $request->status;
        
        if ($request->filled('notes')) {
            $deliveryRequest->gudang_notes = $request->notes;
        }
        
        if ($request->filled('actual_delivery_date')) {
            $deliveryRequest->actual_delivery_date = $request->actual_delivery_date;
        }
        
        if ($request->filled('actual_delivery_time')) {
            $deliveryRequest->actual_delivery_time = $request->actual_delivery_time;
        }

        if ($request->status == 'terlambat') {
            $deliveryRequest->is_rescheduled = true;
            $specificCause = $request->rca_specific_cause;
            $deliveryRequest->rca_reason = $specificCause;
            $deliveryRequest->rca_category = $request->rca_category;
            $deliveryRequest->rca_specific_cause = $specificCause;
            $deliveryRequest->rca_improvement = $request->rca_improvement;
        }
        
        $deliveryRequest->save();

        $statusText = [
            'pending' => 'Pending',
            'process' => 'Dalam Proses',
            'completed' => 'Selesai',
            'terlambat' => 'Terlambat'
        ];

        Notification::create([
            'from_user_id' => Auth::id(),
            'to_user_id' => $deliveryRequest->user_id,
            'content' => 'Status pengiriman Anda telah diubah menjadi: ' . ($statusText[$request->status] ?? $request->status),
            'related_id' => $deliveryRequest->id,
            'is_read' => false,
        ]);

        if ($oldStatus !== $request->status) {
            Notification::create([
                'from_user_id' => Auth::id(),
                'to_role' => 'admin',
                'content' => 'Pengiriman #' . $deliveryRequest->id . ' (' . $deliveryRequest->type_mobil . ') telah diubah menjadi ' . ($statusText[$request->status] ?? $request->status),
                'related_id' => $deliveryRequest->id,
                'is_read' => false,
            ]);
        }
        
        return redirect()->route('gudang.delivery_requests')->with('success', 'Status pengiriman berhasil diperbarui');
    }
    
    public function generateReport(Request $request)
    {
        try {
            $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
            $endDate = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));
            
            $deliveries = DeliveryRequest::with('user')
                ->whereBetween('tanggal_delivery', [$startDate, $endDate])
                ->orderBy('tanggal_delivery', 'asc')
                ->get();

            if ($request->has('download')) {
                $data = [
                    'title' => 'Laporan Pengiriman: ' . date('d/m/Y', strtotime($startDate)) . ' - ' . date('d/m/Y', strtotime($endDate)),
                    'date' => date('d/m/Y'),
                    'deliveries' => $deliveries,
                    'startDate' => $startDate,
                    'endDate' => $endDate,
                    'user' => Auth::user()
                ];
                $pdf = Pdf::loadView('gudang.report_pdf', $data);
                return $pdf->download('laporan-pengiriman-' . $startDate . '-' . $endDate . '.pdf');
            }
            
            return view('gudang.reports', compact('deliveries', 'startDate', 'endDate'));
        } catch (\Exception $e) {
            return back()->with('error', 'Terjadi kesalahan saat membuat PDF: ' . $e->getMessage());
        }
    }
    
    public function notifications()
    {
        $notifications = Notification::where('to_role', 'gudang')
            ->orWhere(function($query) {
                $query->where('to_user_id', Auth::id());
            })
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('gudang.notifications', compact('notifications'));
    }
}