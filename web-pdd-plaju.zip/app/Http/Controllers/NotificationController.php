<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller
{
    public function index()
    {
        $role = Auth::user()->role;
        $notifications = Notification::where(function($query) use ($role) {
                $query->where('to_role', $role)
                    ->orWhere('to_user_id', Auth::id());
            })
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('notifications.index', compact('notifications'));
    }
    
    public function markAsRead($id)
    {
        $notification = Notification::findOrFail($id);
        $notification->is_read = true;
        $notification->save();
        
        return back();
    }
    
    public function markAllAsRead()
    {
        $role = Auth::user()->role;
        Notification::where('is_read', false)
            ->where(function($query) use ($role) {
                $query->where('to_role', $role)
                    ->orWhere('to_user_id', Auth::id());
            })
            ->update(['is_read' => true]);

        return back()->with('success', 'Semua notifikasi telah ditandai dibaca.');
    }

    public function getLatest(Request $request)
    {
        $role = Auth::user()->role;
        $lastId = $request->input('last_id', 0);

        $notifications = Notification::where('id', '>', $lastId)
            ->where(function($query) use ($role) {
                $query->where('to_role', $role)
                      ->orWhere('to_user_id', Auth::id());
            })
            ->orderBy('id', 'asc')
            ->get();
        
        return response()->json($notifications);
    }

    public function getInitialData()
    {
        $role = Auth::user()->role;
        $baseQuery = Notification::where(function($query) use ($role) {
            $query->where('to_role', $role)
                  ->orWhere('to_user_id', Auth::id());
        });

        $unreadCount = (clone $baseQuery)->where('is_read', false)->count();
        $lastId = (clone $baseQuery)->latest('id')->value('id') ?? 0;
        
        return response()->json([
            'unread_count' => $unreadCount,
            'last_id' => $lastId
        ]);
    }
}