<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DeliveryRequest;
use App\Models\User;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Barryvdh\DomPDF\Facade\Pdf;

class AdminController extends Controller
{
    public function salesData(Request $request)
    {
        $selectedType = $request->input('type', 'spv');
        $selectedYear = (int) $request->input('year', Carbon::now()->year);

        $stats = [];
        $chartData = [];
        if ($selectedType == 'salesforce') {
            $listItems = DeliveryRequest::whereNotNull('salesforce')->where('salesforce', '!=', '')
                            ->distinct()->pluck('salesforce');
            foreach ($listItems as $name) {
                $stats[] = [
                    'name' => $name,
                    'total' => DeliveryRequest::where('salesforce', $name)->count(),
                    'pending' => DeliveryRequest::where('salesforce', $name)->where('status', 'pending')->count(),
                    'process' => DeliveryRequest::where('salesforce', $name)->where('status', 'process')->count(),
                    'completed' => DeliveryRequest::where('salesforce', $name)->where('status', 'completed')->count(),
                ];
                $yearlyCounts = [];
                for ($m = 1; $m <= 12; $m++) {
                    $yearlyCounts[] = DeliveryRequest::where('salesforce', $name)
                                            ->whereYear('created_at', $selectedYear)
                                            ->whereMonth('created_at', $m)
                                            ->count();
                }
                $chartData[] = [
                    'name' => $name,
                    'data' => $yearlyCounts,
                ];
            }
        } else {
            $listItems = User::where('role', 'sales')->get();
            foreach ($listItems as $user) {
                $stats[] = [
                    'name' => $user->username,
                    'total' => DeliveryRequest::where('user_id', $user->id)->count(),
                    'pending' => DeliveryRequest::where('user_id', $user->id)->where('status', 'pending')->count(),
                    'process' => DeliveryRequest::where('user_id', $user->id)->where('status', 'process')->count(),
                    'completed' => DeliveryRequest::where('user_id', $user->id)->where('status', 'completed')->count(),
                ];
                $yearlyCounts = [];
                for ($m = 1; $m <= 12; $m++) {
                    $yearlyCounts[] = DeliveryRequest::where('user_id', $user->id)
                                            ->whereYear('created_at', $selectedYear)
                                            ->whereMonth('created_at', $m)
                                            ->count();
                }
                $chartData[] = [
                    'name' => $user->username,
                    'data' => $yearlyCounts,
                ];
            }
        }

        $chartLabels = [];
        for ($m = 1; $m <= 12; $m++) {
            $chartLabels[] = Carbon::create(null, $m, 1)->format('M');
        }

        $years = DeliveryRequest::select(DB::raw('DISTINCT YEAR(created_at) as year'))
                                 ->orderBy('year', 'desc')
                                 ->pluck('year');
        if ($years->isEmpty()) {
            $years = collect([Carbon::now()->year]);
        }
        
        $users = User::orderBy('username')->paginate(10);
        return view('admin.sales_data', compact(
            'stats',
            'chartData',
            'chartLabels',
            'selectedYear',
            'years',
            'selectedType',
            'users'
        ));
    }

    public function deliveryData(Request $request)
    {
        $query = DeliveryRequest::with('user');
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('no_spk', 'like', "%{$search}%")
                    ->orWhere('nama_pemesan', 'like', "%{$search}%")
                    ->orWhere('type_mobil', 'like', "%{$search}%")
                    ->orWhereHas('user', function ($userQuery) use ($search) {
                        $userQuery->where('username', 'like', "%{$search}%");
                    });
            });
        }

        $deliveryRequests = $query->orderBy('id', 'desc')->paginate(10);
        $stats = [
            'total' => DeliveryRequest::count(),
            'pending' => DeliveryRequest::where('status', 'pending')->count(),
            'process' => DeliveryRequest::where('status', 'process')->count(),
            'completed' => DeliveryRequest::where('status', 'completed')->count(),
            'terlambat' => DeliveryRequest::where('status', 'terlambat')->count(),
        ];
        return view('admin.delivery_data', compact('deliveryRequests', 'stats'));
    }

    public function showDelivery($id)
    {
        $deliveryRequest = DeliveryRequest::findOrFail($id);
        return view('admin.show_delivery', compact('deliveryRequest'));
    }

    public function activityLog()
    {
        $activities = Notification::orderBy('id', 'desc')
            ->paginate(20);
        return view('admin.activity_log', compact('activities'));
    }

    public function notifications()
    {
        $notifications = Notification::where('to_role', 'admin')
            ->orWhere('to_user_id', Auth::id())
            ->orderBy('id', 'desc')
            ->paginate(10);
        return view('admin.notifications', compact('notifications'));
    }

    public function rcaDashboard(Request $request)
    {
        $startDate = $request->input('start_date', Carbon::now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', Carbon::now()->endOfMonth()->format('Y-m-d'));

        $latesQuery = DeliveryRequest::where('is_rescheduled', true)->with('user');

        if ($startDate && $endDate) {
            $latesQuery->whereBetween(DB::raw('DATE(updated_at)'), [$startDate, $endDate]);
        }

        $lates = $latesQuery->get();
        $lateCount = $lates->count();

        $totalDeliveries = DeliveryRequest::whereBetween(DB::raw('DATE(updated_at)'), [$startDate, $endDate])->count();
        $categoryCount = $lates->where('rca_category', '!=', null)->countBy('rca_category');

        $monthlyLates = DeliveryRequest::select(
                DB::raw('YEAR(updated_at) as year'),
                DB::raw('MONTH(updated_at) as month'),
                DB::raw('count(*) as count')
            )
            ->where('is_rescheduled', true)
            ->whereBetween(DB::raw('DATE(updated_at)'), [$startDate, $endDate])
            ->groupBy('year', 'month')
            ->orderBy('year', 'asc')->orderBy('month', 'asc')
            ->get();
            
        $chartLabels = $monthlyLates->map(function ($item) {
            return Carbon::createFromDate($item->year, $item->month)->format('M Y');
        });
        $chartData = $monthlyLates->pluck('count');

        $availableDates = DeliveryRequest::select(DB::raw("DATE(updated_at) as date"))
            ->whereNotNull('updated_at')
            ->distinct()
            ->orderBy('date', 'desc')
            ->pluck('date');
            
        $paretoData = [];
        $totalLateForPareto = $lates->whereNotNull('rca_category')->count();
        if ($totalLateForPareto > 0) {
            $grouped = $lates->whereNotNull('rca_category')->groupBy('rca_category')->map->count()->sortDesc();
            $cumulative = 0;
            foreach ($grouped as $category => $count) {
                $percentage = ($count / $totalLateForPareto) * 100;
                $cumulative += $percentage;
                $paretoData[] = [
                    'category' => $category,
                    'count' => $count,
                    'percentage' => round($percentage, 2),
                    'cumulative' => round($cumulative, 2)
                ];
            }
        }

        return view('admin.rca_dashboard', compact(
            'lates',
            'lateCount',
            'totalDeliveries',
            'categoryCount',
            'chartLabels',
            'chartData',
            'startDate',
            'endDate',
            'availableDates',
            'paretoData'
        ));
    }
    
    public function rcaHistory(Request $request)
    {
        $startDate = $request->input('start_date', Carbon::now()->subYear()->startOfYear()->format('Y-m-d'));
        $endDate = $request->input('end_date', Carbon::now()->endOfYear()->format('Y-m-d'));

        $query = DeliveryRequest::where('is_rescheduled', true)->with('user');

        if ($request->filled('start_date') && $request->filled('end_date')) {
            $query->whereBetween('tanggal_delivery', [$request->start_date, $request->end_date]);
        }

        $history = $query->orderBy('tanggal_delivery', 'desc')->paginate(15);

        return view('admin.rca_history', compact('history', 'startDate', 'endDate'));
    }

    public function downloadRcaHistoryReport(Request $request)
    {
        $startDate = $request->input('start_date', Carbon::now()->subYear()->startOfYear()->format('Y-m-d'));
        $endDate = $request->input('end_date', Carbon::now()->endOfYear()->format('Y-m-d'));

        $query = DeliveryRequest::where('is_rescheduled', true)->with('user');

        if ($request->filled('start_date') && $request->filled('end_date')) {
            $query->whereBetween('tanggal_delivery', [$request->start_date, $request->end_date]);
        }

        $history = $query->orderBy('tanggal_delivery', 'desc')->get();
        $data = [
            'title' => 'Laporan Histori Keterlambatan Pengiriman',
            'period' => Carbon::parse($startDate)->format('d F Y') . ' - ' . Carbon::parse($endDate)->format('d F Y'),
            'history' => $history,
        ];
        $pdf = Pdf::loadView('admin.rca_history_pdf', $data);
        $filename = 'laporan-histori-rca-' . $startDate . '-to-' . $endDate . '.pdf';

        return $pdf->download($filename);
    }

    public function downloadRcaReport(Request $request)
    {
        $startDate = $request->input('start_date', Carbon::now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', Carbon::now()->endOfMonth()->format('Y-m-d'));

        $lates = DeliveryRequest::where('is_rescheduled', true)
            ->whereBetween(DB::raw('DATE(updated_at)'), [$startDate, $endDate])
            ->with('user')
            ->get();

        $data = [
            'title' => 'Laporan RCA Keterlambatan',
            'period' => Carbon::parse($startDate)->format('d F Y') . ' - ' . Carbon::parse($endDate)->format('d F Y'),
            'lates' => $lates,
        ];
        $pdf = Pdf::loadView('admin.rca_report_pdf', $data);
        $filename = 'laporan-rca-' . $startDate . '-to-' . $endDate . '.pdf';

        return $pdf->download($filename);
    }

    public function usersIndex()
    {
        $users = User::orderBy('username')->paginate(10);
        return view('admin.users.index', compact('users'));
    }

    public function usersCreate()
    {
        return view('admin.users.create');
    }

    public function usersStore(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|unique:users|min:4|max:20',
            'email' => ['required', 'email', Rule::unique('users')],
            'password' => 'required|min:6',
            'role' => 'required|in:admin,sales,gudang',
        ]);
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        User::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
            'is_active' => true,
        ]);
        return redirect()->route('admin.sales_data')->with('success', 'User berhasil ditambahkan.');
    }

    public function usersEdit(User $user)
    {
        return view('admin.users.edit', compact('user'));
    }

    public function usersUpdate(Request $request, User $user)
    {
        $validator = Validator::make($request->all(), [
            'username' => ['required', 'min:4', 'max:20', Rule::unique('users')->ignore($user->id)],
            'email' => ['required', 'email', Rule::unique('users')->ignore($user->id)],
            'password' => 'nullable|min:6',
            'role' => 'required|in:admin,sales,gudang',
            'is_active' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $user->username = $request->username;
        $user->email = $request->email;
        $user->role = $request->role;
        $user->is_active = $request->is_active;
        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
        }

        $user->save();

        return redirect()->route('admin.sales_data')->with('success', 'User berhasil diperbarui.');
    }

    public function usersDestroy(User $user)
    {
        if ($user->id === Auth::id()) {
            return back()->with('error', 'Anda tidak dapat menghapus akun Anda sendiri.');
        }

        try {
            $user->delete();
            return redirect()->route('admin.sales_data')->with('success', 'User berhasil dihapus.');
        } catch (\Exception $e) {
            return back()->with('error', 'Gagal menghapus user. User ini mungkin terkait dengan data lain.');
        }
    }

    public function updateDeliveryStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required',
            'rca_reason' => 'nullable|string',
            'rca_category' => 'nullable|string',
            'actual_delivery_date' => 'nullable|date',
            'actual_delivery_time' => 'nullable'
        ]);
        $delivery = DeliveryRequest::findOrFail($id);

        if (strtolower($request->status) === 'reschedule') {
            $delivery->status = 'terlambat';
            $delivery->is_rescheduled = true;
        }
        elseif (strtolower($request->status) === 'selesai') {
            $delivery->status = 'selesai';
        } else {
            $delivery->status = strtolower($request->status);
        }

        $delivery->rca_reason = $request->rca_reason;
        $delivery->rca_category = $request->rca_category;
        if ($request->filled('actual_delivery_date') && $request->filled('actual_delivery_time')) {
            $delivery->actual_delivery_date = Carbon::parse($request->actual_delivery_date . ' ' . $request->actual_delivery_time);
        }

        $delivery->save();

        if (strtolower($request->status) === 'reschedule') {
            Notification::create([
                'message' => 'Pengiriman dijadwalkan ulang (Reschedule)',
                'to_user_id' => $delivery->user_id,
                'link' => route('admin.showDelivery', $delivery->id),
            ]);
        }

        return redirect()->back()->with('success', 'Status pengiriman berhasil diperbarui.');
    }
}