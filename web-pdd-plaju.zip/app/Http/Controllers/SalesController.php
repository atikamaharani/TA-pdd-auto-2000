<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DeliveryRequest;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class SalesController extends Controller
{
    public function showInputForm()
    {
        return view('sales.input_delivery');
    }
    
    public function storeDeliveryRequest(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'salesforce' => 'required|string|max:255',
            'nama_pemesan' => 'required|string|max:255',
            'no_hp' => 'required|string|max:20',
            'no_spk' => 'required|string|max:50',
            'type_mobil' => 'required|string|max:100',
            'warna' => 'required|string|max:50',
            'posisi_unit' => 'required|string|max:100',
            'no_rangka' => 'required|string|max:100',
            'cara_bayar' => 'required|string|max:50',
            'leasing' => 'nullable|string|max:100',
            'status_transaksi' => 'required|string|max:50',
            'tanggal_delivery' => 'required|date',
            'jam_delivery' => 'required',
            'lokasi_delivery' => 'required|string|max:255',
            'catatan' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        
        $deliveryRequest = DeliveryRequest::create([
            'user_id' => Auth::id(),
            'salesforce' => $request->salesforce,
            'nama_pemesan' => $request->nama_pemesan,
            'no_hp' => $request->no_hp,
            'no_spk' => $request->no_spk,
            'type_mobil' => $request->type_mobil,
            'warna' => $request->warna,
            'posisi_unit' => $request->posisi_unit,
            'no_rangka' => $request->no_rangka,
            'cara_bayar' => $request->cara_bayar,
            'leasing' => $request->leasing,
            'status_transaksi' => $request->status_transaksi,
            'tanggal_delivery' => $request->tanggal_delivery,
            'jam_delivery' => $request->jam_delivery,
            'lokasi_delivery' => $request->lokasi_delivery,
            'catatan' => $request->catatan,
            'status' => 'pending',
        ]);

        Notification::create([
            'from_user_id' => Auth::id(),
            'to_role' => 'gudang',
            'content' => 'Permintaan pengiriman baru: ' . $request->type_mobil . ' untuk ' . $request->nama_pemesan,
            'related_id' => $deliveryRequest->id,
            'is_read' => false,
        ]);

        Notification::create([
            'from_user_id' => Auth::id(),
            'to_role' => 'admin',
            'content' => 'Permintaan pengiriman baru diajukan oleh ' . Auth::user()->username . ': ' . $request->type_mobil,
            'related_id' => $deliveryRequest->id,
            'is_read' => false,
        ]);

        return redirect()->route('sales.deliveries')->with('success', 'Permintaan pengiriman berhasil dibuat');
    }
    
   public function deliveries(Request $request)
    {
        $userId = Auth::id();
        $query = DeliveryRequest::where('user_id', $userId);

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('no_spk', 'like', "%{$search}%")
                    ->orWhere('nama_pemesan', 'like', "%{$search}%")
                    ->orWhere('type_mobil', 'like', "%{$search}%");
            });
        }
        
        // Pengurutan sudah berdasarkan ID terakhir
        $deliveryRequests = $query->orderBy('id', 'desc')->paginate(10);
        return view('sales.deliveries', compact('deliveryRequests'));
    }

    public function edit($id)
    {
        $deliveryRequest = DeliveryRequest::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        return view('sales.edit_delivery', compact('deliveryRequest'));
    }

    public function update(Request $request, $id)
    {
        $deliveryRequest = DeliveryRequest::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        $validator = Validator::make($request->all(), [
            'salesforce' => 'required|string|max:255',
            'nama_pemesan' => 'required|string|max:255',
            'no_hp' => 'required|string|max:20',
            'no_spk' => 'required|string|max:50',
            'type_mobil' => 'required|string|max:100',
            'warna' => 'required|string|max:50',
            'posisi_unit' => 'required|string|max:100',
            'no_rangka' => 'required|string|max:100',
            'cara_bayar' => 'required|string|max:50',
            'leasing' => 'nullable|string|max:100',
            'status_transaksi' => 'required|string|max:50',
            'tanggal_delivery' => 'required|date',
            'jam_delivery' => 'required',
            'lokasi_delivery' => 'required|string|max:255',
            'catatan' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $deliveryRequest->update($request->all());

        Notification::create([
            'from_user_id' => Auth::id(),
            'to_role' => 'gudang',
            'content' => 'Pembaruan pada permintaan pengiriman #' . $deliveryRequest->id . ' oleh ' . Auth::user()->username,
            'related_id' => $deliveryRequest->id,
            'is_read' => false,
        ]);
        
        Notification::create([
            'from_user_id' => Auth::id(),
            'to_role' => 'admin',
            'content' => 'Pembaruan pada permintaan pengiriman #' . $deliveryRequest->id . ' oleh ' . Auth::user()->username,
            'related_id' => $deliveryRequest->id,
            'is_read' => false,
        ]);

        return redirect()->route('sales.deliveries')->with('success', 'Permintaan pengiriman berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $deliveryRequest = DeliveryRequest::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        Notification::where('related_id', $deliveryRequest->id)
            ->where(function ($query) use ($deliveryRequest) {
                $query->where('content', 'LIKE', '%Permintaan pengiriman baru: ' . $deliveryRequest->type_mobil . '%')
                      ->orWhere('content', 'LIKE', '%Pembaruan pada permintaan pengiriman #' . $deliveryRequest->id . '%')
                      ->orWhere('content', 'LIKE', '%Status pengiriman Anda telah diubah menjadi%')
                      ->orWhere('content', 'LIKE', '%Pengiriman #' . $deliveryRequest->id . ' telah diubah menjadi%');
            })
            ->delete();

        $deliveryRequest->delete();

        Notification::create([
            'from_user_id' => Auth::id(),
            'to_role' => 'admin',
            'content' => 'Permintaan pengiriman #' . $id . ' (' . $deliveryRequest->type_mobil . ' - ' . $deliveryRequest->nama_pemesan . ') telah dihapus oleh ' . Auth::user()->username,
            'related_id' => null, 
            'is_read' => false,
        ]);

        Notification::create([
            'from_user_id' => Auth::id(),
            'to_role' => 'gudang',
            'content' => 'Permintaan pengiriman #' . $id . ' (' . $deliveryRequest->type_mobil . ' - ' . $deliveryRequest->nama_pemesan . ') telah dihapus oleh ' . Auth::user()->username,
            'related_id' => null,
            'is_read' => false,
        ]);

        return redirect()->route('sales.deliveries')->with('success', 'Permintaan pengiriman berhasil dihapus.');
    }
    
    public function statistics()
    {
        $userId = Auth::id();
        $dailyStats = DeliveryRequest::where('user_id', $userId)
            ->whereDate('created_at', now())
            ->count();
        $monthlyStats = DeliveryRequest::where('user_id', $userId)
            ->whereMonth('created_at', now()->month)
            ->whereYear('created_at', now()->year)
            ->count();
        $yearlyStats = DeliveryRequest::where('user_id', $userId)
            ->whereYear('created_at', now()->year)
            ->count();
        $topCarTypes = DeliveryRequest::where('user_id', $userId)
            ->select('type_mobil', DB::raw('count(*) as total'))
            ->groupBy('type_mobil')
            ->orderBy('total', 'desc')
            ->limit(10) 
            ->get();
        $pendingCount = DeliveryRequest::where('user_id', $userId)
            ->where('status', 'pending')
            ->count();
        $processCount = DeliveryRequest::where('user_id', $userId)
            ->where('status', 'process')
            ->count();
        $completedCount = DeliveryRequest::where('user_id', $userId)
            ->where('status', 'completed')
            ->count();
        return view('sales.statistics', compact('dailyStats', 'monthlyStats', 'yearlyStats', 'topCarTypes', 'pendingCount', 'processCount', 'completedCount'));
    }

    public function showDeliveryDetail($id)
    {
        $userId = Auth::id();
        $delivery = DeliveryRequest::where('id', $id)
            ->where('user_id', $userId)
            ->firstOrFail();
        return view('sales.delivery_detail', compact('delivery'));
    }
    
    public function trackDelivery($id)
    {
        $userId = Auth::id();
        $delivery = DeliveryRequest::where('id', $id)
            ->where('user_id', $userId)
            ->firstOrFail();
        $statusHistory = [
            [
                'status' => 'pending',
                'date' => $delivery->created_at->format('d/m/Y H:i'),
                'description' => 'Permintaan pengiriman dibuat'
            ]
        ];
        if ($delivery->status == 'process' || $delivery->status == 'completed') {
            $statusHistory[] = [
                'status' => 'process',
                'date' => $delivery->updated_at->format('d/m/Y H:i'),
                'description' => 'Kendaraan sedang disiapkan'
            ];
        }
        
        if ($delivery->status == 'completed') {
            $statusHistory[] = [
                'status' => 'completed',
                'date' => $delivery->actual_delivery_date ? $delivery->actual_delivery_date->format('d/m/Y') . ' ' . $delivery->actual_delivery_time : 'N/A',
                'description' => 'Kendaraan telah terkirim'
            ];
        }
        
        return view('sales.track_delivery', compact('delivery', 'statusHistory'));
    }
    
    public function monthlyReport()
    {
        $userId = Auth::id();
        $currentMonth = now()->month;
        $currentYear = now()->year;
        
        $deliveries = DeliveryRequest::where('user_id', $userId)
            ->whereMonth('created_at', $currentMonth)
            ->whereYear('created_at', $currentYear)
            ->orderBy('created_at', 'desc')
            ->get();
        $statusCounts = [
            'pending' => $deliveries->where('status', 'pending')->count(),
            'process' => $deliveries->where('status', 'process')->count(),
            'completed' => $deliveries->where('status', 'completed')->count(),
        ];
        $carTypes = $deliveries->pluck('type_mobil')->countBy();
        
        return view('sales.monthly_report', compact('deliveries', 'statusCounts', 'carTypes', 'currentMonth', 'currentYear'));
    }
}