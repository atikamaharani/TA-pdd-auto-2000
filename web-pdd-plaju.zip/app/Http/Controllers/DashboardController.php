<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\DeliveryRequest;
use App\Models\User;
use App\Models\Notification;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function admin()
    {
        $salesCount = User::where('role', 'sales')->count();
        $deliveryCount = DeliveryRequest::count();
        $completedDeliveries = DeliveryRequest::where('status', 'completed')->count();
        
        $recentDeliveries = DeliveryRequest::with('user')
            ->orderBy('id', 'desc')
            ->take(3)
            ->get();
        $totalRecentDeliveries = DeliveryRequest::count();

        $notifications = Notification::where(function($query) {
                $query->where('to_role', 'admin')
                      ->orWhere('to_user_id', Auth::id());
            })
            ->orderBy('id', 'desc')
            ->take(3)
            ->get();
        $totalNotifications = Notification::where(function($query) {
                $query->where('to_role', 'admin')
                      ->orWhere('to_user_id', Auth::id());
            })
            ->count();
            
        return view('dashboard.admin', compact('salesCount', 'deliveryCount', 'completedDeliveries', 'recentDeliveries', 'totalRecentDeliveries', 'notifications', 'totalNotifications'));
    }

    public function sales()
    {
        $userId = Auth::id();

        $myDeliveries = DeliveryRequest::where('user_id', $userId)
            ->orderBy('id', 'desc')
            ->take(3)
            ->get();
            
        $totalMyDeliveries = DeliveryRequest::where('user_id', $userId)->count();
            
        $statistics = [
            'total' => DeliveryRequest::where('user_id', $userId)->count(),
            'pending' => DeliveryRequest::where('user_id', $userId)->where('status', 'pending')->count(),
            'process' => DeliveryRequest::where('user_id', $userId)->where('status', 'process')->count(),
            'completed' => DeliveryRequest::where('user_id', $userId)->where('status', 'completed')->count(),
        ];

        $notifications = Notification::where(function($query) use ($userId) {
                $query->where('to_role', 'sales')
                      ->orWhere('to_user_id', $userId);
            })
            ->orderBy('id', 'desc')
            ->take(3)
            ->get();

        $totalNotifications = Notification::where(function($query) use ($userId) {
                $query->where('to_role', 'sales')
                      ->orWhere('to_user_id', $userId);
            })
            ->count();

        $deliveryTargetDate = Carbon::now()->addDays(2)->toDateString();
        $isReminderNeeded = DeliveryRequest::where('user_id', $userId)
            ->whereDate('tanggal_delivery', $deliveryTargetDate)
            ->doesntExist();

        return view('dashboard.sales', compact('myDeliveries', 'totalMyDeliveries', 'statistics', 'notifications', 'totalNotifications', 'isReminderNeeded', 'deliveryTargetDate'));
    }

    public function gudang()
    {
        $latestRequestsForGudang = DeliveryRequest::with('user')
            ->orderBy('id', 'desc')
            ->take(3)
            ->get();
        $totalRequestsForGudang = DeliveryRequest::count();

        $statistics = [
            'request' => DeliveryRequest::count(),
            'process' => DeliveryRequest::where('status', 'process')->count(),
            'completed' => DeliveryRequest::where('status', 'completed')->count(),
        ];

        $notifications = Notification::where(function($query) {
                $query->where('to_role', 'gudang')
                      ->orWhere('to_user_id', Auth::id());
            })
            ->orderBy('id', 'desc')
            ->take(3)
            ->get();
            
        $totalNotifications = Notification::where(function($query) {
                $query->where('to_role', 'gudang')
                      ->orWhere('to_user_id', Auth::id());
            })
            ->count();

        return view('dashboard.gudang', compact(
            'latestRequestsForGudang', 
            'totalRequestsForGudang', 
            'statistics', 
            'notifications', 
            'totalNotifications'
        ));
    }
}