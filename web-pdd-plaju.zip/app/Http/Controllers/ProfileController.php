<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Log;

class ProfileController extends Controller
{
    public function show()
    {
        $user = Auth::user();
        return view('profile.show', compact('user'));
    }

    public function edit()
    {
        $user = Auth::user();
        return view('profile.edit', compact('user'));
    }

    public function update(Request $request)
    {
        $user = Auth::user();
        $validator = Validator::make($request->all(), [
            'username' => [
                'required',
                'string',
                'min:4',
                'max:20',
                Rule::unique('users')->ignore($user->id),
            ],
            'email' => [
                'required',
                'email',
                Rule::unique('users')->ignore($user->id),
            ],
            'current_password' => 'nullable|required_with:password',
            'password' => 'nullable|min:6|confirmed',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10048',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }


        if ($request->filled('password')) {
            if (!Hash::check($request->current_password, $user->password)) {
                return back()->withErrors(['current_password' => 'Password saat ini tidak benar.'])->withInput();
            }
        }


        if ($request->hasFile('avatar')) {
            try {

                if ($user->avatar && Storage::disk('public')->exists($user->avatar)) {
                    Storage::disk('public')->delete($user->avatar);
                }

                $avatarPath = $request->file('avatar')->store('avatars', 'public');
                $user->avatar = $avatarPath;
            } catch (\Exception $e) {
                Log::error('Avatar upload failed for user ID ' . $user->id . ': ' . $e->getMessage());
                return back()->withErrors(['avatar' => 'Gagal mengunggah avatar. Silakan coba lagi.'])->withInput();
            }
        }

        $user->username = $request->username;
        $user->email = $request->email;

        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
        }

        try {
            if ($user->save()) {
                return redirect()->route('profile.show')->with('success', 'Profile berhasil diperbarui.');
            } else {
                Log::error('User save failed for user ID ' . $user->id . ' without throwing an exception.');
                return back()->with('error', 'Gagal memperbarui profile. Terjadi kesalahan pada server.')->withInput();
            }
        } catch (\Exception $e) {
            Log::error('User save failed for user ID ' . $user->id . ': ' . $e->getMessage());
            return back()->with('error', 'Gagal memperbarui profile: ' . $e->getMessage())->withInput();
        }
    }

    public function removeAvatar()
    {
        $user = Auth::user();
        try {
            if ($user->avatar && Storage::disk('public')->exists($user->avatar)) {
                Storage::disk('public')->delete($user->avatar);
                $user->avatar = null;
                if (!$user->save()) {
                    Log::error('User save failed after avatar removal for user ID ' . $user->id);
                    return back()->with('error', 'Gagal menghapus avatar dari database.');
                }
            }
        } catch (\Exception $e) {
            Log::error('Avatar removal failed for user ID ' . $user->id . ': ' . $e->getMessage());
            return back()->with('error', 'Gagal menghapus avatar: ' . $e->getMessage());
        }

        return back()->with('success', 'Avatar berhasil dihapus.');
    }
}
