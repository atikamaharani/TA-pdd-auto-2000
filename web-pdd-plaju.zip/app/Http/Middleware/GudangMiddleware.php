<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class GudangMiddleware
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check() || Auth::user()->role !== 'gudang' || !Auth::user()->is_active) {
            return redirect()->route('login')->with('error', 'Anda tidak memiliki akses gudang.');
        }
        
        return $next($request);
    }
}